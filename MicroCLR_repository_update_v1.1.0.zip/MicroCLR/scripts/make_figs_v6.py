#!/usr/bin/env python3
"""Regenerate main-text Figures 1, 2, 5, 8 for manuscript v6.

- Fig 1 (within-disease heatmap): drop IBD column (exploratory), add the two
  novel augmentations (present in Table 1 but missing from the v5 figure).
- Fig 2 (IGC2 LOCO heatmap): drop IBD column, add novel augmentations.
- Fig 5 (low-label curves): CRC only (IBD -> exploratory supplementary).
- Fig 8 (LP vs FT vs RF): drop IBD panel, apply harmonized palette
  (blue #0279EE = MicroCLR, gray #8C8C8C = no-pre-training control,
   orange #FF9400 = Random Forest baseline) per Reviewer 3.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

matplotlib.rcParams["svg.fonttype"] = "none"
matplotlib.rcParams["font.family"] = ["Liberation Sans", "Arimo", "DejaVu Sans"]

EV = "/workspace/repo_extract/MicroCLR/evaluation"
OUT = "/workspace/work"

cv = pd.read_csv(f"{EV}/cv_results.csv")
cv_novel = pd.read_csv(f"{EV}/cv_results_novel_augs.csv")
loco = pd.read_csv(f"{EV}/loco_results.csv")
loco_novel = pd.read_csv(f"{EV}/loco_results_novel_augs.csv")
ll = pd.read_csv(f"{EV}/lowlabel_results.csv")

DISPLAY = {
    "MicroCLR-PhyloAug": "PhyloAug",
    "MicroCLR-CompAug": "CompAug",
    "MicroCLR-TaxDropAug": "TaxDropAug",
    "MicroCLR-FeatureMask": "FeatureMask",
    "MicroCLR-GaussianNoise": "GaussianNoise",
    "MicroCLR-MixupAug": "MixupAug",
    "MicroCLR-EcologicalAug": "EcologicalAug",
    "MicroCLR-CohortStyleAug": "CohortStyleAug",
    "RF": "Random Forest",
    "XGBoost": "XGBoost",
    "LogReg": "Logistic Regression",
    "MicroCLR-RawCLR": "MicroCLR-RawCLR",
    "VAE+LR": "VAE + Linear Probe",
    "SCARF": "SCARF",
    "ComBat+RF": "ComBat + RF",
}
ORDER = list(DISPLAY.keys())
GROUP_EDGES = [8, 11, 15]  # MicroCLR LP | supervised | SSL (row indices for separators)

def mean_matrix(df, diseases):
    rows = []
    for m in ORDER:
        row = []
        for d in diseases:
            sub = df[(df.method == m) & (df.disease == d)]
            row.append(sub.AUROC.mean() if len(sub) else np.nan)
        rows.append(row)
    return pd.DataFrame(rows, index=[DISPLAY[m] for m in ORDER], columns=diseases)

def draw_heatmap(mat, vmin, vmax, title, fname, figsize, cbar_label="AUROC",
                 near_random=False, group_edges=None):
    fig, ax = plt.subplots(figsize=figsize)
    im = sns.heatmap(mat, cmap="RdYlGn", vmin=vmin, vmax=vmax,
                     annot=True, fmt=".3f", annot_kws={"fontsize": 9},
                     cbar_kws={"label": cbar_label}, linewidths=0.5,
                     linecolor="white", ax=ax,
                     cbar=True)
    ax.set_aspect("auto")
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Disease", fontsize=11)
    ax.set_ylabel("Method", fontsize=11)
    plt.setp(ax.get_xticklabels(), rotation=0, fontsize=10)
    plt.setp(ax.get_yticklabels(), rotation=0, fontsize=9)
    if group_edges:
        for e in group_edges[:-1]:
            ax.axhline(e, color="black", linewidth=2.2)
    if near_random:
        # mark the near-random reference inside the colorbar
        cbar = ax.collections[0].colorbar
        cbar.ax.axhline(0.5, color="black", linestyle=":", linewidth=1.4)
        cbar.ax.text(0.5, 0.515, "near random", transform=cbar.ax.transData,
                     ha="center", va="bottom", fontsize=7.5, color="black")
    fig.tight_layout()
    fig.savefig(f"{OUT}/{fname}.png", dpi=300, bbox_inches="tight")
    fig.savefig(f"{OUT}/{fname}.svg", bbox_inches="tight")
    plt.close(fig)
    print(f"saved {fname}.png/.svg")

# ---------------------------------------------------------------- Figure 1
cv_all = pd.concat([cv, cv_novel], ignore_index=True)
mat1 = mean_matrix(cv_all, ["CRC", "T2D", "PD"])
draw_heatmap(mat1, 0.5, 1.0, "Within-Disease AUROC (5-fold CV)",
             "fig1_within_cohort_benchmark_v2", (6.8, 7.6),
             group_edges=GROUP_EDGES)

# ---------------------------------------------------------------- Figure 2
loco_novel_f = (loco_novel[loco_novel.protocol == "loco"]
                if "protocol" in loco_novel.columns else loco_novel)
loco_all = pd.concat([loco, loco_novel_f], ignore_index=True)
mat2 = mean_matrix(loco_all, ["CRC", "T2D"])
draw_heatmap(mat2, 0.3, 0.7, "Cross-Cohort AUROC (Leave-One-Cohort-Out)",
             "fig3_loco_benchmark_v2", (4.6, 7.6), near_random=True,
             group_edges=GROUP_EDGES)

# ---------------------------------------------------------------- Figure 5
crc = ll[ll.disease == "CRC"]
fracs = [0.1, 0.25, 0.5, 1.0]
xticks = ["10%", "25%", "50%", "100%"]
series = [
    ("MicroCLR-PhyloAug", "#0279EE", "-", "o", "MicroCLR-PhyloAug"),
    ("MicroCLR-FeatureMask", "#FD9BED", "-", "o", "MicroCLR-FeatureMask"),
    ("MicroCLR-GaussianNoise", "#E9ED4C", "-", "o", "MicroCLR-GaussianNoise"),
    ("RF", "black", "--", "o", "Random Forest"),
    ("LogReg", "gray", ":", "o", "Logistic Regression"),
]
fig, ax = plt.subplots(figsize=(6.4, 4.6))
for method, color, ls, marker, label in series:
    means = [crc[(crc.method == method) & (crc.frac == f)].AUROC.mean() for f in fracs]
    sds = [crc[(crc.method == method) & (crc.frac == f)].AUROC.std(ddof=1) for f in fracs]
    x = np.arange(len(fracs))
    ax.plot(x, means, ls, color=color, marker=marker, markersize=6, linewidth=2, label=label)
    ax.fill_between(x, np.array(means) - np.array(sds), np.array(means) + np.array(sds),
                    color=color, alpha=0.15, linewidth=0)
ax.set_xticks(np.arange(len(fracs)), xticks)
ax.set_xlabel("Labeled data (%)", fontsize=11)
ax.set_ylabel("AUROC", fontsize=11)
ax.set_title("Low-Label Regime: AUROC vs. Fraction of Labeled Data (CRC)",
             fontsize=12, fontweight="bold")
ax.legend(fontsize=8.5, loc="lower right", framealpha=0.9)
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(f"{OUT}/fig4_lowlabel_curves_v2.png", dpi=300, bbox_inches="tight")
fig.savefig(f"{OUT}/fig4_lowlabel_curves_v2.svg", bbox_inches="tight")
plt.close(fig)
print("saved fig4_lowlabel_curves_v2.png/.svg")

# ---------------------------------------------------------------- Figure 8
# LP/FT/RF comparison, 3 diseases, harmonized palette
ft_vals = {  # (PhyloAug FT, FeatureMask FT, MLP-RandomInit, RF) per disease
    "CRC": [(0.807, 0.098), (0.827, 0.118), (0.835, 0.081), (0.864, 0.051)],
    "T2D": [(0.625, 0.055), (0.635, 0.076), (0.625, 0.029), (0.658, 0.062)],
    "PD":  [(0.977, 0.021), (0.953, 0.053), (0.986, 0.009), (0.999, 0.003)],
}
lp_vals = {  # (PhyloAug LP, FeatureMask LP) per disease
    "CRC": [(0.765, 0.046), (0.838, 0.028)],
    "T2D": [(0.604, 0.066), (0.601, 0.054)],
    "PD":  [(0.990, 0.018), (0.979, 0.029)],
}
BLUE, GRAY, ORANGE = "#0279EE", "#8C8C8C", "#FF9400"
fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.4))
bars = ["PhyloAug\n(LP)", "FeatureMask\n(LP)", "PhyloAug\n(FT)", "FeatureMask\n(FT)",
        "MLP-\nRandomInit", "Random\nForest"]
for ax, disease in zip(axes, ["CRC", "T2D", "PD"]):
    vals, errs, colors, hatches = [], [], [], []
    for v in lp_vals[disease]:
        vals.append(v[0]); errs.append(v[1]); colors.append(BLUE); hatches.append("///")
    for v in ft_vals[disease][:2]:
        vals.append(v[0]); errs.append(v[1]); colors.append(BLUE); hatches.append("")
    vals.append(ft_vals[disease][2][0]); errs.append(ft_vals[disease][2][1])
    colors.append(GRAY); hatches.append("")
    vals.append(ft_vals[disease][3][0]); errs.append(ft_vals[disease][3][1])
    colors.append(ORANGE); hatches.append("")
    x = np.arange(6)
    ax.bar(x, vals, yerr=errs, color=colors, hatch=hatches, edgecolor="black",
           linewidth=0.6, capsize=3, error_kw={"elinewidth": 1})
    rf = ft_vals[disease][3][0]
    ax.axhline(rf, color=ORANGE, linestyle="--", linewidth=1.6)
    ax.set_title(disease, fontsize=12, fontweight="bold")
    ax.set_xticks(x, bars, fontsize=7.5, rotation=45, ha="right")
    ax.set_ylabel("AUROC" if disease == "CRC" else "", fontsize=11)
    ax.set_ylim(min(vals) - 4 * max(errs), min(1.02, max(vals) + 4 * max(errs)))
fig.suptitle("Within-Disease AUROC: Linear Probe vs Full Fine-Tuning vs Random Forest",
             fontsize=13, fontweight="bold", y=0.99)
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
handles = [
    Patch(facecolor=BLUE, hatch="///", edgecolor="black", label="Linear Probe (frozen encoder)"),
    Patch(facecolor=BLUE, edgecolor="black", label="Full Fine-Tuning (unfrozen encoder)"),
    Patch(facecolor=GRAY, edgecolor="black", label="MLP-RandomInit (no pre-training)"),
    Patch(facecolor=ORANGE, edgecolor="black", label="Random Forest"),
    Line2D([0], [0], color=ORANGE, linestyle="--", label="RF reference (dashed)"),
]
fig.legend(handles=handles, loc="upper center", ncol=5, fontsize=8.5,
           bbox_to_anchor=(0.5, 0.955), frameon=False)
fig.tight_layout(rect=[0, 0, 1, 0.88])
fig.savefig(f"{OUT}/fig6_finetuning_comparison_v2.png", dpi=300, bbox_inches="tight")
fig.savefig(f"{OUT}/fig6_finetuning_comparison_v2.svg", bbox_inches="tight")
plt.close(fig)
print("saved fig6_finetuning_comparison_v2.png/.svg")
