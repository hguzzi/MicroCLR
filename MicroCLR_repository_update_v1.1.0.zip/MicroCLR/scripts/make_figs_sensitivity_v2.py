#!/usr/bin/env python3
"""Regenerate main-text Figures 7, 9, 10 with the harmonized palette (R3):

    blue #0279EE  = MicroCLR / FeatureMask variants
    gray #8C8C8C  = baseline / nuisance quantity
    orange #FF9400 = reserved for Random Forest ONLY (not used here)

- Fig 7 (silhouette): disease = blue, cohort = gray (was blue/orange, which
  collided with the RF-reserved orange).
- Fig 9 (re-centering): original = solid blue, re-centered = hatched light blue
  (was blue/orange). Error bars recomputed with ddof=1 (sample SD), matching
  the convention used everywhere else in v6.
- Fig 10 (masking rate): sequential blues for the ordinal masking rate
  (was blue/teal/orange/pink categorical).
"""
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from matplotlib.lines import Line2D

matplotlib.rcParams["svg.fonttype"] = "none"
matplotlib.rcParams["font.family"] = ["Liberation Sans", "Arimo", "DejaVu Sans"]

RES = "/mnt/shared-workspace/microclr_data/results"
EV = "/workspace/repo_extract/MicroCLR/evaluation"
OUT = "/workspace/work"

BLUE, LIGHTBLUE, GRAY = "#0279EE", "#7FB8F0", "#8C8C8C"
SEQ_BLUES = ["#BFD9F7", "#8FBFF5", "#55A0F2", "#0279EE"]  # rate 0.1 -> 0.7
GREEN, RED = "#75A025", "#D62728"  # delta sign annotations (sign also in text)

# ============================================================= Figure 7
sil = pd.read_csv(f"{EV}/silhouette_scores.csv")
order = ["RawCLR", "MicroCLR-PhyloAug", "MicroCLR-CompAug",
         "MicroCLR-TaxDropAug", "MicroCLR-FeatureMask", "MicroCLR-GaussianNoise"]
labels = ["RawCLR", "PhyloAug", "CompAug", "TaxDropAug", "FeatureMask", "GaussianNoise"]
sil = sil.set_index("method").loc[order]

fig, ax = plt.subplots(figsize=(7.6, 4.6))
x = np.arange(len(order))
ax.bar(x - 0.2, sil.sil_disease, width=0.4, color=BLUE, edgecolor="black",
       linewidth=0.6, label="Silhouette (disease)")
ax.bar(x + 0.2, sil.sil_cohort, width=0.4, color=GRAY, edgecolor="black",
       linewidth=0.6, label="Silhouette (cohort)")
ax.axhline(0, color="black", linestyle="--", linewidth=1)
ax.set_xticks(x, labels, rotation=45, ha="right", fontsize=10)
ax.set_ylabel("Silhouette Score (cosine)", fontsize=11)
ax.set_title("Embedding Quality: Disease vs. Cohort Silhouette",
             fontsize=13, fontweight="bold")
ax.legend(fontsize=9, framealpha=0.9)
ax.grid(axis="y", alpha=0.25)
fig.tight_layout()
fig.savefig(f"{OUT}/fig5_silhouette_scores_v2.png", dpi=300, bbox_inches="tight")
fig.savefig(f"{OUT}/fig5_silhouette_scores_v2.svg", bbox_inches="tight")
plt.close(fig)
print("saved fig5_silhouette_scores_v2.png/.svg")

# ============================================================= Figure 9
with open(f"{RES}/recentering_results.json") as f:
    rec = json.load(f)

def stats(d, folds):
    v = np.asarray(folds)
    return v.mean(), v.std(ddof=1)

cv_diseases = ["CRC", "T2D", "PD"]   # IBD excluded: exploratory (participant leakage, Sec 3.13)
loco_diseases = ["CRC", "T2D"]       # same reason
fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.6))

# Panel A: within-disease 5-fold CV
ax = axes[0]
x = np.arange(len(cv_diseases))
orig_m, orig_e, rec_m, rec_e, deltas = [], [], [], [], []
for d in cv_diseases:
    m, e = stats(d, rec["cv_original"][d]["folds"])
    orig_m.append(m); orig_e.append(e)
    m, e = stats(d, rec["cv_recentered"][d]["folds"])
    rec_m.append(m); rec_e.append(e)
    deltas.append(rec_m[-1] - orig_m[-1])
ax.bar(x - 0.2, orig_m, yerr=orig_e, width=0.4, color=BLUE, edgecolor="black",
       linewidth=0.6, capsize=3, error_kw={"elinewidth": 1}, label="FeatureMask (original)")
ax.bar(x + 0.2, rec_m, yerr=rec_e, width=0.4, color=LIGHTBLUE, hatch="///",
       edgecolor="black", linewidth=0.6, capsize=3, error_kw={"elinewidth": 1},
       label="FeatureMask (re-centered)")
for xi, (om, rm) in enumerate(zip(orig_m, rec_m)):
    d = rm - om
    c = GREEN if d > 0 else RED
    top = max(om + orig_e[xi], rm + rec_e[xi])
    ax.text(xi, top + 0.015, f"$\\Delta$={d:+.3f}", ha="center", fontsize=8.5,
            color=c, fontweight="bold")
ax.axhline(0.5, color="gray", linestyle="--", linewidth=1)
ax.set_xticks(x, cv_diseases, fontsize=10)
ax.set_ylabel("AUROC (mean $\\pm$ SD)", fontsize=11)
ax.set_ylim(0.5, 1.06)
ax.set_title("A  Within-disease 5-fold CV", fontsize=12, fontweight="bold", loc="left")
ax.legend(fontsize=8.5, loc="upper left", framealpha=0.9)
ax.grid(axis="y", alpha=0.25)

# Panel B: LOCO
ax = axes[1]
x = np.arange(len(loco_diseases))
orig_m, orig_e, rec_m, rec_e, deltas = [], [], [], [], []
for d in loco_diseases:
    m, e = stats(d, rec["loco_original"][d]["splits"])
    orig_m.append(m); orig_e.append(e)
    m, e = stats(d, rec["loco_recentered"][d]["splits"])
    rec_m.append(m); rec_e.append(e)
    deltas.append(rec_m[-1] - orig_m[-1])
ax.bar(x - 0.2, orig_m, yerr=orig_e, width=0.4, color=BLUE, edgecolor="black",
       linewidth=0.6, capsize=3, error_kw={"elinewidth": 1}, label="FeatureMask (original)")
ax.bar(x + 0.2, rec_m, yerr=rec_e, width=0.4, color=LIGHTBLUE, hatch="///",
       edgecolor="black", linewidth=0.6, capsize=3, error_kw={"elinewidth": 1},
       label="FeatureMask (re-centered)")
for xi, (om, rm) in enumerate(zip(orig_m, rec_m)):
    d = rm - om
    c = GREEN if d > 0 else RED
    top = max(om + orig_e[xi], rm + rec_e[xi])
    ax.text(xi, top + 0.02, f"$\\Delta$={d:+.3f}", ha="center", fontsize=8.5,
            color=c, fontweight="bold")
ax.axhline(0.5, color="gray", linestyle="--", linewidth=1)
ax.set_xticks(x, loco_diseases, fontsize=10)
ax.set_ylabel("AUROC (mean $\\pm$ SD)", fontsize=11)
ax.set_ylim(0.3, 1.0)
ax.set_title("B  Cross-cohort (LOCO)", fontsize=12, fontweight="bold", loc="left")
ax.legend(handles=ax.get_legend_handles_labels()[0] +
          [Line2D([0], [0], color="gray", linestyle="--", label="Random (0.5)")],
          fontsize=8.5, loc="upper left", framealpha=0.9)
ax.grid(axis="y", alpha=0.25)

fig.suptitle("Re-centering sensitivity: FeatureMask with and without CLR zero-sum re-centering",
             fontsize=13, fontweight="bold", y=0.99)
fig.tight_layout(rect=[0, 0, 1, 0.93])
fig.savefig(f"{OUT}/fig_recentering_sensitivity_v2.png", dpi=300, bbox_inches="tight")
fig.savefig(f"{OUT}/fig_recentering_sensitivity_v2.svg", bbox_inches="tight")
plt.close(fig)
print("saved fig_recentering_sensitivity_v2.png/.svg")

# ============================================================= Figure 10
with open(f"{RES}/masking_rate_cv_results.json") as f:
    mask = json.load(f)
rates = ["0.1", "0.3", "0.5", "0.7"]
diseases = ["CRC", "T2D", "PD"]  # IBD excluded: exploratory (Sec 3.13)
# zoomed per-panel y-ranges (as in the original figure) so rate differences stay readable
YLIM = {"CRC": (0.65, 1.00), "T2D": (0.50, 0.76), "IBD": (0.825, 1.00), "PD": (0.88, 1.005)}
fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.8))
for ax, disease in zip(axes, diseases):
    means = [mask[r][disease]["mean"] for r in rates]
    errs = [np.asarray(mask[r][disease]["folds"]).std(ddof=1) for r in rates]
    best = int(np.argmax(means))
    x = np.arange(len(rates))
    ax.bar(x, means, yerr=errs, color=SEQ_BLUES, edgecolor="black", linewidth=0.6,
           capsize=3, error_kw={"elinewidth": 1})
    ax.patches[best].set_linewidth(1.8)
    lo, hi = YLIM[disease]
    for xi in range(len(rates)):
        top = means[xi] + errs[xi]
        if top + 0.02 * (hi - lo) < hi:  # label fits above the error bar
            ax.text(xi, top + 0.02 * (hi - lo), f"{means[xi]:.3f}", ha="center",
                    fontsize=8.5, fontweight="bold")
        else:  # place inside the bar top
            ax.text(xi, means[xi] - 0.03 * (hi - lo), f"{means[xi]:.3f}", ha="center",
                    va="top", fontsize=8.5, fontweight="bold")
    if lo <= 0.5 <= hi:
        ax.axhline(0.5, color="gray", linestyle="--", linewidth=1)
    ax.set_xticks(x, rates, fontsize=9)
    ax.set_xlabel("Masking rate", fontsize=10)
    ax.set_ylim(lo, hi)
    ax.set_title(disease, fontsize=12, fontweight="bold")
    if disease == "CRC":
        ax.set_ylabel("AUROC (mean $\\pm$ SD)", fontsize=10)
fig.suptitle("Augmentation strength sensitivity: FeatureMask masking rate (0.1--0.7)",
             fontsize=13, fontweight="bold", y=0.99)
fig.tight_layout(rect=[0, 0, 1, 0.92])
fig.savefig(f"{OUT}/fig_masking_sensitivity_v2.png", dpi=300, bbox_inches="tight")
fig.savefig(f"{OUT}/fig_masking_sensitivity_v2.svg", bbox_inches="tight")
plt.close(fig)
print("saved fig_masking_sensitivity_v2.png/.svg")

# ---- sanity print: ddof=1 values used for fig 9 error bars
print("\nFig 9 ddof=1 check (CV):")
for d in cv_diseases:
    o = np.asarray(rec["cv_original"][d]["folds"])
    r = np.asarray(rec["cv_recentered"][d]["folds"])
    print(f"  {d}: orig {o.mean():.3f}±{o.std(ddof=1):.3f}  recentered {r.mean():.3f}±{r.std(ddof=1):.3f}  Δ{r.mean()-o.mean():+.3f}")
