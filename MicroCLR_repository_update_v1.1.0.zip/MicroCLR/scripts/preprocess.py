"""
preprocess.py — MicroCLR data preprocessing pipeline
=====================================================
Applies CLR (centered log-ratio) transformation to raw relative abundance
profiles and generates reproducible train/test splits.

Usage:
    python scripts/preprocess.py \
        --input  raw_abundance.csv \
        --meta   metadata.csv \
        --outdir data/

Input format:
    raw_abundance.csv : samples × MSP features, relative abundances (rows sum to 1)
    metadata.csv      : columns: sample_id, disease, label (0/1), cohort

Output:
    data/features_clr_verified.csv.gz   CLR-transformed features
    data/metadata_verified.csv          Cleaned metadata
    data/cv_splits_verified.json        5-fold stratified CV splits (seed=42)
    data/loco_splits_verified.json      Leave-One-Cohort-Out splits
"""

import argparse
import json
import gzip
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold


def clr_transform(X: np.ndarray, pseudocount: float = 1e-6) -> np.ndarray:
    """Centered log-ratio transformation with pseudocount for zero handling."""
    X_pseudo = X + pseudocount
    log_X = np.log(X_pseudo)
    clr = log_X - log_X.mean(axis=1, keepdims=True)
    return clr


def make_cv_splits(sample_ids, labels, n_splits=5, seed=42):
    """Stratified k-fold splits. Returns dict keyed by fold index."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    splits = {}
    for fold, (train_idx, test_idx) in enumerate(skf.split(sample_ids, labels)):
        splits[str(fold)] = {
            "train": [sample_ids[i] for i in train_idx],
            "test":  [sample_ids[i] for i in test_idx],
        }
    return splits


def make_loco_splits(sample_ids, cohorts, diseases):
    """Leave-One-Cohort-Out splits, grouped by disease.
    Only diseases with >=2 cohorts are included (CRC, T2D, IBD).
    """
    meta = pd.DataFrame({"sample_id": sample_ids, "cohort": cohorts, "disease": diseases})
    splits = {}
    for disease in meta["disease"].unique():
        sub = meta[meta["disease"] == disease]
        cohort_list = sub["cohort"].unique().tolist()
        if len(cohort_list) < 2:
            continue
        splits[disease] = {}
        for held_out in cohort_list:
            train_ids = sub[sub["cohort"] != held_out]["sample_id"].tolist()
            test_ids  = sub[sub["cohort"] == held_out]["sample_id"].tolist()
            splits[disease][held_out] = {"train": train_ids, "test": test_ids}
    return splits


def main():
    parser = argparse.ArgumentParser(description="MicroCLR preprocessing pipeline")
    parser.add_argument("--input",  required=True, help="Raw abundance CSV (samples × features)")
    parser.add_argument("--meta",   required=True, help="Metadata CSV (sample_id, disease, label, cohort)")
    parser.add_argument("--outdir", default="data/", help="Output directory")
    args = parser.parse_args()

    import os
    os.makedirs(args.outdir, exist_ok=True)

    # --- Load ---
    print("Loading raw data...")
    X_raw = pd.read_csv(args.input, index_col=0)
    meta  = pd.read_csv(args.meta)
    meta  = meta.set_index("sample_id")

    # Align
    common = X_raw.index.intersection(meta.index)
    X_raw  = X_raw.loc[common]
    meta   = meta.loc[common]
    print(f"  {len(common)} samples × {X_raw.shape[1]} features after alignment")

    # --- CLR transform ---
    print("Applying CLR transformation...")
    X_clr = clr_transform(X_raw.values)
    clr_df = pd.DataFrame(X_clr, index=X_raw.index, columns=X_raw.columns)

    out_features = os.path.join(args.outdir, "features_clr_verified.csv.gz")
    clr_df.to_csv(out_features, compression="gzip")
    print(f"  Saved: {out_features}")

    out_meta = os.path.join(args.outdir, "metadata_verified.csv")
    meta.reset_index().to_csv(out_meta, index=False)
    print(f"  Saved: {out_meta}")

    # --- CV splits ---
    print("Generating 5-fold stratified CV splits (seed=42)...")
    sample_ids = list(meta.index)
    labels     = meta["label"].values
    cv_splits  = {}
    for disease in meta["disease"].unique():
        mask = meta["disease"] == disease
        sub_ids    = [s for s, m in zip(sample_ids, mask) if m]
        sub_labels = labels[mask]
        cv_splits[disease] = make_cv_splits(sub_ids, sub_labels, n_splits=5, seed=42)

    out_cv = os.path.join(args.outdir, "cv_splits_verified.json")
    with open(out_cv, "w") as f:
        json.dump(cv_splits, f)
    print(f"  Saved: {out_cv}")

    # --- LOCO splits ---
    print("Generating LOCO splits...")
    loco_splits = make_loco_splits(
        sample_ids=sample_ids,
        cohorts=meta["cohort"].tolist(),
        diseases=meta["disease"].tolist(),
    )
    out_loco = os.path.join(args.outdir, "loco_splits_verified.json")
    with open(out_loco, "w") as f:
        json.dump(loco_splits, f)
    print(f"  Saved: {out_loco}")

    print("\nPreprocessing complete.")


if __name__ == "__main__":
    main()
