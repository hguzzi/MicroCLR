
"""
Low-label fine-tuning experiment.
Tests whether pre-trained initialization helps more when labeled data is scarce.
Protocol matches ft_cv_results.csv exactly, with the addition of label-fraction subsampling.

Validation strategy: fixed val set drawn from full fold training set (20% stratified),
then subsample labeled training from the remaining 80%. This ensures reliable early stopping
even at 10% labels (CRC fold0: 16 labeled samples but 33 val samples).
"""

import json, os, sys, warnings
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import roc_auc_score, average_precision_score, balanced_accuracy_score, matthews_corrcoef
from sklearn.model_selection import StratifiedShuffleSplit
from concurrent.futures import ProcessPoolExecutor, as_completed
import traceback

warnings.filterwarnings("ignore")

DATA_DIR   = "/mnt/shared-workspace/microclr_data"
MODEL_DIR  = f"{DATA_DIR}/models"
RESULT_DIR = f"{DATA_DIR}/results"
OUT_FILE   = f"{RESULT_DIR}/ft_lowlabel_results.csv"

DISEASES   = ["CRC", "T2D", "IBD"]
FRACS      = [0.10, 0.25, 0.50]
N_REPEATS  = 5
BASE_SEED  = 42
MAX_EPOCHS = 100
BATCH_SIZE = 64
VAL_FRAC   = 0.20
LR_ENC     = 1e-4
LR_HEAD    = 1e-3
WD         = 1e-4
ES_PATIENCE = 10
SCHED_PATIENCE = 5

AUGMENTATIONS = ["PhyloAug", "CompAug", "TaxDropAug", "FeatureMask", "GaussianNoise"]

class MicroCLREncoder(nn.Module):
    def __init__(self, n_features=426):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(n_features, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Linear(256, 128),
        )
    def forward(self, x):
        return self.encoder(x)

class ProjectionHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.head = nn.Sequential(nn.Linear(128, 64), nn.ReLU(), nn.Linear(64, 64))
    def forward(self, x):
        return self.head(x)

class MicroCLRModel(nn.Module):
    def __init__(self, n_features=426):
        super().__init__()
        self.encoder   = MicroCLREncoder(n_features)
        self.projector = ProjectionHead()

class FineTuneModel(nn.Module):
    def __init__(self, encoder):
        super().__init__()
        self.encoder = encoder
        self.head = nn.Sequential(
            nn.Linear(128, 64),
            nn.Dropout(0.3),
            nn.Linear(64, 1),
        )
    def forward(self, x):
        return self.head(self.encoder(x))

def load_encoder(aug_name):
    ckpt_path = f"{MODEL_DIR}/microclr_{aug_name}.pt"
    ckpt = torch.load(ckpt_path, map_location="cpu")
    full_model = MicroCLRModel(n_features=426)
    full_model.load_state_dict(ckpt["model_state_dict"])
    return full_model.encoder

def make_random_encoder():
    enc = MicroCLREncoder(n_features=426)
    for m in enc.modules():
        if isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            nn.init.zeros_(m.bias)
    return enc

def compute_metrics(y_true, y_score):
    auroc = roc_auc_score(y_true, y_score)
    auprc = average_precision_score(y_true, y_score)
    y_pred = (np.array(y_score) >= 0.5).astype(int)
    bal_acc = balanced_accuracy_score(y_true, y_pred)
    mcc = matthews_corrcoef(y_true, y_pred)
    return auroc, auprc, bal_acc, mcc

def train_one_run(encoder, X_train, y_train, X_val, y_val, X_test, y_test, seed):
    torch.manual_seed(seed)
    np.random.seed(seed)

    model = FineTuneModel(encoder)
    n_pos = y_train.sum()
    n_neg = len(y_train) - n_pos
    pos_weight = torch.tensor([n_neg / max(n_pos, 1)], dtype=torch.float32)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    optimizer = torch.optim.Adam([
        {"params": model.encoder.parameters(), "lr": LR_ENC},
        {"params": model.head.parameters(),    "lr": LR_HEAD},
    ], weight_decay=WD)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=SCHED_PATIENCE
    )

    Xt  = torch.tensor(X_train, dtype=torch.float32)
    yt  = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)
    Xv  = torch.tensor(X_val,   dtype=torch.float32)
    yv  = torch.tensor(y_val,   dtype=torch.float32)
    Xte = torch.tensor(X_test,  dtype=torch.float32)
    yte = torch.tensor(y_test,  dtype=torch.float32)

    bs = min(BATCH_SIZE, len(Xt))
    loader = DataLoader(TensorDataset(Xt, yt), batch_size=bs, shuffle=True)

    best_val_auroc = -1.0
    best_state = None
    no_improve = 0
    epochs_run = 0

    for epoch in range(MAX_EPOCHS):
        model.train()
        for xb, yb in loader:
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()

        model.eval()
        with torch.no_grad():
            val_scores = torch.sigmoid(model(Xv)).squeeze().numpy()
        if len(np.unique(yv.numpy())) < 2:
            val_auroc = 0.5
        else:
            val_auroc = roc_auc_score(yv.numpy(), val_scores)

        scheduler.step(val_auroc)
        epochs_run = epoch + 1

        if val_auroc > best_val_auroc:
            best_val_auroc = val_auroc
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= ES_PATIENCE:
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    model.eval()
    with torch.no_grad():
        test_scores = torch.sigmoid(model(Xte)).squeeze().numpy()

    auroc, auprc, bal_acc, mcc = compute_metrics(yte.numpy(), test_scores)
    return auroc, auprc, bal_acc, mcc, epochs_run

def run_job(args):
    disease, aug_name, frac, fold_idx, repeat_idx, X_dis, y_dis, train_ids, test_ids, sid_to_dis_idx = args
    try:
        seed = BASE_SEED + repeat_idx

        train_idx = [sid_to_dis_idx[s] for s in train_ids if s in sid_to_dis_idx]
        test_idx  = [sid_to_dis_idx[s] for s in test_ids  if s in sid_to_dis_idx]

        X_fold_train = X_dis[train_idx]
        y_fold_train = y_dis[train_idx]
        X_test       = X_dis[test_idx]
        y_test       = y_dis[test_idx]

        # carve fixed val from full fold train
        sss_val = StratifiedShuffleSplit(n_splits=1, test_size=VAL_FRAC, random_state=seed)
        avail_local, val_local = next(sss_val.split(X_fold_train, y_fold_train))
        X_avail = X_fold_train[avail_local]
        y_avail = y_fold_train[avail_local]
        X_val   = X_fold_train[val_local]
        y_val   = y_fold_train[val_local]

        if y_avail.sum() < 1 or (len(y_avail) - y_avail.sum()) < 1:
            return None

        n_labeled = max(2, int(len(X_avail) * frac))
        if n_labeled >= len(X_avail):
            X_train = X_avail
            y_train = y_avail
        else:
            sss_sub = StratifiedShuffleSplit(n_splits=1, train_size=n_labeled, random_state=seed)
            sub_idx, _ = next(sss_sub.split(X_avail, y_avail))
            X_train = X_avail[sub_idx]
            y_train = y_avail[sub_idx]

        if y_train.sum() < 1 or (len(y_train) - y_train.sum()) < 1:
            return None

        if aug_name == "MLP-RandomInit":
            encoder = make_random_encoder()
        else:
            encoder = load_encoder(aug_name)

        auroc, auprc, bal_acc, mcc, epochs = train_one_run(
            encoder, X_train, y_train, X_val, y_val, X_test, y_test, seed
        )

        method = "MLP-RandomInit" if aug_name == "MLP-RandomInit" else f"{aug_name} (FT)"
        return {
            "AUROC": auroc, "AUPRC": auprc, "BalAcc": bal_acc, "MCC": mcc,
            "disease": disease, "method": method,
            "frac": frac, "repeat": repeat_idx, "fold": fold_idx, "epochs": epochs,
        }
    except Exception as e:
        return {"error": str(e), "tb": traceback.format_exc(),
                "disease": disease, "method": aug_name, "frac": frac,
                "repeat": repeat_idx, "fold": fold_idx}

def main():
    features = pd.read_csv(f"{DATA_DIR}/processed/features_clr_verified.csv.gz", index_col=0)
    metadata = pd.read_csv(f"{DATA_DIR}/processed/metadata_verified.csv")
    with open(f"{DATA_DIR}/processed/cv_splits_verified.json") as f:
        cv_splits = json.load(f)

    aug_list = AUGMENTATIONS + ["MLP-RandomInit"]
    all_jobs = []

    for disease in DISEASES:
        dis_meta = metadata[metadata["disease"] == disease].reset_index(drop=True)
        dis_sids = dis_meta["sample.ID"].tolist()
        dis_idx_global = [metadata[metadata["sample.ID"]==s].index[0] for s in dis_sids]
        X_dis = features.values.astype(np.float32)[dis_idx_global]
        y_dis = dis_meta["label"].values.astype(np.float32)
        sid_to_dis_idx = {sid: i for i, sid in enumerate(dis_sids)}

        folds = cv_splits[disease]
        for fold_idx, fold in enumerate(folds):
            for frac in FRACS:
                for repeat_idx in range(N_REPEATS):
                    for aug_name in aug_list:
                        all_jobs.append((
                            disease, aug_name, frac, fold_idx, repeat_idx,
                            X_dis, y_dis,
                            fold["train"], fold["test"],
                            sid_to_dis_idx,
                        ))

    print(f"Total jobs: {len(all_jobs)}", flush=True)
    n_workers = min(8, os.cpu_count() or 4)
    print(f"Workers: {n_workers}", flush=True)

    results = []
    errors  = []
    completed = 0

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        futures = {pool.submit(run_job, job): job for job in all_jobs}
        for fut in as_completed(futures):
            completed += 1
            res = fut.result()
            if res is None:
                pass
            elif "error" in res:
                errors.append(res)
                print(f"  ERR {res['disease']} {res['method']} f={res['frac']} "
                      f"fold={res['fold']} rep={res['repeat']}: {res['error'][:60]}", flush=True)
            else:
                results.append(res)
            if completed % 200 == 0:
                print(f"  {completed}/{len(all_jobs)} done ({len(results)} ok)", flush=True)

    print(f"\nFinished: {len(results)} results, {len(errors)} errors.", flush=True)
    df = pd.DataFrame(results)
    df.to_csv(OUT_FILE, index=False)
    print(f"Saved: {OUT_FILE}", flush=True)
    print(df.groupby(["disease","method","frac"])["AUROC"].mean().unstack("frac").round(3).to_string(), flush=True)

    if errors:
        pd.DataFrame(errors).to_csv(f"{RESULT_DIR}/ft_lowlabel_errors.csv", index=False)

if __name__ == "__main__":
    main()
