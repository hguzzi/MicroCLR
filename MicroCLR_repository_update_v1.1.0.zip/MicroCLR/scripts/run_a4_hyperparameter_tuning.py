#!/usr/bin/env python3
"""
A4: Hyperparameter tuning via nested cross-validation on CMD CRC.

Outer loop: 5-fold CV (evaluation)
Inner loop: 3-fold CV (model selection over hyperparameter grid)

Search spaces:
  FeatureMask: masking_rate, tau, batch_size
  RF: n_estimators, max_depth, min_samples_leaf
  LogReg: C (regularization strength)
"""

import json, os, warnings, itertools
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
import torch
import torch.nn as nn
import torch.nn.functional as F

warnings.filterwarnings("ignore")

# ── Paths ────────────────────────────────────────────────────────────────────
DATA_DIR = "/workspace/cmd_data/processed"
OUT_DIR = "/workspace/cmd_results"
os.makedirs(OUT_DIR, exist_ok=True)

# ── Load data ────────────────────────────────────────────────────────────────
features_df = pd.read_csv(f"{DATA_DIR}/cmd_features_clr.csv.gz", index_col=0)
metadata_df = pd.read_csv(f"{DATA_DIR}/cmd_metadata_processed.csv", index_col=0)

# Align
common = features_df.index.intersection(metadata_df.index)
features_df = features_df.loc[common]
metadata_df = metadata_df.loc[common]

# CRC subset
crc_mask = metadata_df['study_condition'].isin(['CRC', 'control'])
X_all = features_df[crc_mask].values.astype(np.float32)
y_all = (metadata_df.loc[crc_mask, 'study_condition'] == 'CRC').values.astype(int)
print(f"CRC: {len(X_all)} samples, {y_all.sum()} cases, {X_all.shape[1]} features")

# ── Encoder ──────────────────────────────────────────────────────────────────
class Encoder(nn.Module):
    def __init__(self, input_dim=342, hidden_dims=[512, 256, 128], proj_dim=64):
        super().__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.extend([nn.Linear(prev, h), nn.BatchNorm1d(h), nn.ReLU()])
            prev = h
        self.encoder = nn.Sequential(*layers)
        self.projector = nn.Sequential(
            nn.Linear(prev, proj_dim), nn.BatchNorm1d(proj_dim), nn.ReLU(),
            nn.Linear(proj_dim, proj_dim)
        )
    def forward(self, x):
        return F.normalize(self.projector(self.encoder(x)), dim=-1)
    def embed(self, x):
        return self.encoder(x).detach()

def feature_mask_aug(x, masking_rate=0.3):
    mask = (torch.rand_like(x) > masking_rate).float()
    return x * mask

def nt_xent_loss(z1, z2, tau=0.07):
    batch = z1.shape[0]
    z = torch.cat([z1, z2], dim=0)
    sim = torch.mm(z, z.t().contiguous()) / tau
    sim.fill_diagonal_(-1e9)
    labels = torch.cat([torch.arange(batch, 2*batch), torch.arange(batch)]).to(z.device)
    return F.cross_entropy(sim, labels)

def pretrain_encoder(X, masking_rate=0.3, tau=0.07, batch_size=128, epochs=100, lr=3e-4, seed=42):
    torch.manual_seed(seed)
    np.random.seed(seed)
    encoder = Encoder(X.shape[1])
    optimizer = torch.optim.Adam(encoder.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    Xt = torch.from_numpy(X)
    n = len(Xt)
    encoder.train()
    for epoch in range(epochs):
        perm = torch.randperm(n)
        total_loss = 0
        for i in range(0, n, batch_size):
            idx = perm[i:i+batch_size]
            xb = Xt[idx]
            x1 = feature_mask_aug(xb, masking_rate)
            x2 = feature_mask_aug(xb, masking_rate)
            z1, z2 = encoder(x1), encoder(x2)
            loss = nt_xent_loss(z1, z2, tau)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(idx)
        scheduler.step()
    return encoder

def extract_embeddings(encoder, X):
    encoder.eval()
    with torch.no_grad():
        return encoder.embed(torch.from_numpy(X)).numpy()

def eval_lp(Xtr, ytr, Xte, yte, C=1.0):
    clf = LogisticRegression(C=C, max_iter=1000, solver='lbfgs')
    clf.fit(Xtr, ytr)
    return roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])

def eval_rf(Xtr, ytr, Xte, yte, n_estimators=200, max_depth=None, min_samples_leaf=1):
    clf = RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth,
                                  min_samples_leaf=min_samples_leaf, random_state=42)
    clf.fit(Xtr, ytr)
    return roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])

# ── Hyperparameter grids ─────────────────────────────────────────────────────
# Reduced grids for tractability
fm_params = list(itertools.product([0.2, 0.3, 0.5], [0.07], [128]))  # 3 configs
rf_params = list(itertools.product([100, 200, 500], [None, 20], [1, 5]))  # 12 configs
lp_params = [0.1, 1.0, 10.0]  # 3 configs

print(f"Grid sizes: FM={len(fm_params)}, RF={len(rf_params)}, LP={len(lp_params)}")

outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
inner_cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)

results = {
    'nested_cv': {},
    'best_params': {},
    'grid_info': {
        'fm_configs': len(fm_params),
        'rf_configs': len(rf_params),
        'lp_configs': len(lp_params),
        'inner_folds': 3,
        'outer_folds': 5,
    }
}

outer_aurocs = {'FM_LP': [], 'RF': [], 'LP_orig': []}
best_params_per_fold = {'FM_LP': [], 'RF': [], 'LP_orig': []}

for fold, (train_idx, test_idx) in enumerate(outer_cv.split(X_all, y_all)):
    print(f"\n=== Outer fold {fold+1}/5 ===")
    X_train, X_test = X_all[train_idx], X_all[test_idx]
    y_train, y_test = y_all[train_idx], y_all[test_idx]

    # --- Tune RF on original features ---
    best_rf_auroc = -1
    best_rf_param = None
    for n_est, max_d, min_leaf in rf_params:
        inner_aurocs = []
        for in_tr, in_te in inner_cv.split(X_train, y_train):
            auroc = eval_rf(X_train[in_tr], y_train[in_tr], X_train[in_te], y_train[in_te],
                           n_estimators=n_est, max_depth=max_d, min_samples_leaf=min_leaf)
            inner_aurocs.append(auroc)
        mean_auroc = np.mean(inner_aurocs)
        if mean_auroc > best_rf_auroc:
            best_rf_auroc = mean_auroc
            best_rf_param = (n_est, max_d, min_leaf)

    rf_test = eval_rf(X_train, y_train, X_test, y_test,
                      n_estimators=best_rf_param[0], max_depth=best_rf_param[1],
                      min_samples_leaf=best_rf_param[2])
    outer_aurocs['RF'].append(rf_test)
    best_params_per_fold['RF'].append(best_rf_param)
    print(f"  RF best: {best_rf_param} -> test AUROC={rf_test:.3f}")

    # --- Tune LP on original features ---
    best_lp_auroc = -1
    best_lp_C = None
    for C in lp_params:
        inner_aurocs = []
        for in_tr, in_te in inner_cv.split(X_train, y_train):
            auroc = eval_lp(X_train[in_tr], y_train[in_tr], X_train[in_te], y_train[in_te], C=C)
            inner_aurocs.append(auroc)
        mean_auroc = np.mean(inner_aurocs)
        if mean_auroc > best_lp_auroc:
            best_lp_auroc = mean_auroc
            best_lp_C = C

    lp_test = eval_lp(X_train, y_train, X_test, y_test, C=best_lp_C)
    outer_aurocs['LP_orig'].append(lp_test)
    best_params_per_fold['LP_orig'].append(best_lp_C)
    print(f"  LP orig best C={best_lp_C} -> test AUROC={lp_test:.3f}")

    # --- Tune FM+LP (reduced: only masking_rate, fixed tau=0.07, batch=128) ---
    best_fm_auroc = -1
    best_fm_param = None
    for mr, tau, bs in fm_params:
        inner_aurocs = []
        for in_tr, in_te in inner_cv.split(X_train, y_train):
            enc = pretrain_encoder(X_train[in_tr], masking_rate=mr, tau=tau,
                                   batch_size=bs, epochs=50)  # reduced epochs for tuning
            emb = extract_embeddings(enc, X_train[in_tr])
            emb_te = extract_embeddings(enc, X_train[in_te])
            auroc = eval_lp(emb, y_train[in_tr], emb_te, y_train[in_te], C=1.0)
            inner_aurocs.append(auroc)
        mean_auroc = np.mean(inner_aurocs)
        if mean_auroc > best_fm_auroc:
            best_fm_auroc = mean_auroc
            best_fm_param = (mr, tau, bs)

    enc = pretrain_encoder(X_train, masking_rate=best_fm_param[0], tau=best_fm_param[1],
                           batch_size=best_fm_param[2], epochs=100)
    emb_train = extract_embeddings(enc, X_train)
    emb_test = extract_embeddings(enc, X_test)
    fm_test = eval_lp(emb_train, y_train, emb_test, y_test, C=1.0)
    outer_aurocs['FM_LP'].append(fm_test)
    best_params_per_fold['FM_LP'].append(best_fm_param)
    print(f"  FM+LP best: mr={best_fm_param[0]} -> test AUROC={fm_test:.3f}")

# Summary
for method in ['FM_LP', 'RF', 'LP_orig']:
    aurocs = outer_aurocs[method]
    results['nested_cv'][method] = {
        'mean': float(np.mean(aurocs)),
        'std': float(np.std(aurocs)),
        'folds': aurocs,
    }
    results['best_params'][method] = best_params_per_fold[method]
    print(f"\n{method}: {np.mean(aurocs):.3f}±{np.std(aurocs):.3f}")
    print(f"  Best params per fold: {best_params_per_fold[method]}")

print("\n=== Comparison: tuned vs default ===")
print(f"  FM+LP (tuned):   {results['nested_cv']['FM_LP']['mean']:.3f}±{results['nested_cv']['FM_LP']['std']:.3f}")
print(f"  FM+LP (default): 0.878±0.009 (from A2)")
print(f"  RF (tuned):      {results['nested_cv']['RF']['mean']:.3f}±{results['nested_cv']['RF']['std']:.3f}")
print(f"  RF (default):    0.884±0.017 (from A2)")

with open(f"{OUT_DIR}/A4_hyperparameter_tuning.json", 'w') as f:
    json.dump(results, f, indent=2)
print(f"\nSaved to {OUT_DIR}/A4_hyperparameter_tuning.json")
