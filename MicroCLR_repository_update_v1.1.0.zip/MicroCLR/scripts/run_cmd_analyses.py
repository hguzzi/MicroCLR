#!/usr/bin/env python3
"""
CMD robustness analyses for the MicroCLR revision (BIOADV-2026-484).

A2: Participant-grouped CV vs sample-level CV (leakage quantification)
A3: Inductive vs transductive pre-training
A5: Mixup alternative configurations (standard vs same-lambda vs FeatureMask)
A6: Linear vs nonlinear classifiers on embeddings

Dataset: curatedMetagenomicData (CMD) extended validation set.
Preprocessing (see preprocess_cmd.py): MetaPhlAn3 species profiles, CLR-transformed
with pseudocount 1e-6, features present in >=10% of samples.

NOTE: this file was reconstructed after a workspace reset from the verbatim
A5/A6/main-block segments and the logged outputs; A2/A3 use the same helpers
and protocol parameters as the original run (encoder 342-512-256-128, projection
128-64-64, NT-Xent tau=0.07, batch 128, lr 3e-4, 150 epochs, Adam + cosine
annealing, 5-fold stratified CV with seed 42).
"""

import json, os, warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, GroupKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
import torch
import torch.nn as nn
import torch.nn.functional as F

warnings.filterwarnings("ignore")

DATA_DIR = "/workspace/cmd_data/processed"
OUT_DIR = "/workspace/cmd_results"
os.makedirs(OUT_DIR, exist_ok=True)

features_df = pd.read_csv(f"{DATA_DIR}/cmd_features_clr.csv.gz", index_col=0)
metadata_df = pd.read_csv(f"{DATA_DIR}/cmd_metadata_processed.csv", index_col=0)
common = features_df.index.intersection(metadata_df.index)
features_df = features_df.loc[common]
metadata_df = metadata_df.loc[common]

def get_disease_subset(disease, features, metadata):
    mask = metadata['study_condition'].isin([disease, 'control'])
    X = features[mask].values.astype(np.float32)
    y = (metadata.loc[mask, 'study_condition'] == disease).values.astype(int)
    subjects = metadata.loc[mask, 'subject_id'].values
    return X, y, subjects, mask.index.values

# ── Encoder / augmentation / loss (shared with A4 script) ────────────────────
class Encoder(nn.Module):
    def __init__(self, input_dim=342, hidden_dims=[512, 256, 128], proj_dim=64):
        super().__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.extend([nn.Linear(prev, h), nn.BatchNorm1d(h), nn.ReLU()])
            prev = h
        self.encoder = nn.Sequential(*layers)
        self.projector = nn.Sequential(
            nn.Linear(prev, proj_dim), nn.BatchNorm1d(proj_dim), nn.ReLU(),
            nn.Linear(proj_dim, proj_dim))
    def forward(self, x):
        return F.normalize(self.projector(self.encoder(x)), dim=-1)
    def embed(self, x):
        return self.encoder(x).detach()

def feature_mask_aug(x, masking_rate=0.3):
    return x * (torch.rand_like(x) > masking_rate).float()

def nt_xent_loss(z1, z2, tau=0.07):
    batch = z1.shape[0]
    z = torch.cat([z1, z2], dim=0)
    sim = torch.mm(z, z.t().contiguous()) / tau
    sim.fill_diagonal_(-1e9)
    labels = torch.cat([torch.arange(batch, 2 * batch), torch.arange(batch)]).to(z.device)
    return F.cross_entropy(sim, labels)

def pretrain_encoder(X, aug_type='feature_mask', masking_rate=0.3, tau=0.07,
                     batch_size=128, epochs=150, lr=3e-4, seed=42, verbose=False):
    torch.manual_seed(seed); np.random.seed(seed)
    encoder = Encoder(X.shape[1])
    optimizer = torch.optim.Adam(encoder.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    Xt = torch.from_numpy(X)
    n = len(Xt)
    losses = []
    encoder.train()
    for epoch in range(epochs):
        perm = torch.randperm(n)
        total = 0.0
        for i in range(0, n, batch_size):
            idx = perm[i:i + batch_size]
            xb = Xt[idx]
            if aug_type == 'feature_mask':
                x1 = feature_mask_aug(xb, masking_rate)
                x2 = feature_mask_aug(xb, masking_rate)
            elif aug_type == 'mixup':          # independent lambda per view
                lam1, lam2 = np.random.beta(0.4, 0.4), np.random.beta(0.4, 0.4)
                p = torch.randperm(n)[0:len(idx)]
                x1 = lam1 * xb + (1 - lam1) * Xt[p]
                p = torch.randperm(n)[0:len(idx)]
                x2 = lam2 * xb + (1 - lam2) * Xt[p]
            elif aug_type == 'mixup_same_lambda':  # identical lambda for both views
                lam = np.random.beta(0.4, 0.4)
                p = torch.randperm(n)[0:len(idx)]
                x1 = lam * xb + (1 - lam) * Xt[p]
                x2 = lam * xb + (1 - lam) * Xt[p]
            z1, z2 = encoder(x1), encoder(x2)
            loss = nt_xent_loss(z1, z2, tau)
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            total += loss.item() * len(idx)
        losses.append(total / n)
        if verbose and (epoch + 1) % 50 == 0:
            print(f"    Epoch {epoch+1}/{epochs} loss={losses[-1]:.4f}")
    scheduler.step()
    return encoder, losses

def extract_embeddings(encoder, X):
    encoder.eval()
    with torch.no_grad():
        return encoder.embed(torch.from_numpy(X)).numpy()

def evaluate_linear_probe(Xtr, ytr, Xte, yte):
    clf = LogisticRegression(max_iter=1000)
    clf.fit(Xtr, ytr)
    return roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])

def evaluate_rf(Xtr, ytr, Xte, yte):
    clf = RandomForestClassifier(n_estimators=200, random_state=42)
    clf.fit(Xtr, ytr)
    return roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])

# ── A2: Participant-Grouped CV vs Sample-Level CV ────────────────────────────
def run_participant_grouped_cv(features, metadata, diseases=['CRC', 'IBD', 'T2D']):
    """
    Compare sample-level stratified splitting vs participant-grouped splitting
    (GroupKFold with subject_id as group key); FeatureMask augmentation;
    no disease or cohort labels used during pre-training.
    """
    print("\n" + "=" * 70)
    print("A2: Participant-Grouped CV vs Sample-Level CV")
    print("=" * 70)
    results = {}
    for disease in diseases:
        print(f"\n--- {disease} ---")
        X, y, subjects, _ = get_disease_subset(disease, features, metadata)
        print(f"  {len(X)} samples, {y.sum()} cases, {len(set(subjects))} subjects")

        print("  Pretraining encoder (transductive, FeatureMask)...")
        encoder, _ = pretrain_encoder(X, aug_type='feature_mask', epochs=150, verbose=True)
        embeddings = extract_embeddings(encoder, X)

        skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        gkf = GroupKFold(n_splits=5)
        sample_lp, sample_rf, group_lp, group_rf = [], [], [], []
        for tr, te in skf.split(X, y):
            sample_lp.append(evaluate_linear_probe(embeddings[tr], y[tr], embeddings[te], y[te]))
            sample_rf.append(evaluate_rf(X[tr], y[tr], X[te], y[te]))
        for tr, te in gkf.split(X, y, groups=subjects):
            group_lp.append(evaluate_linear_probe(embeddings[tr], y[tr], embeddings[te], y[te]))
            group_rf.append(evaluate_rf(X[tr], y[tr], X[te], y[te]))

        results[disease] = {
            'n_samples': len(X), 'n_cases': int(y.sum()), 'n_subjects': len(set(subjects)),
            'sample_level_cv': {
                'FeatureMask_LP': {'mean': float(np.mean(sample_lp)), 'std': float(np.std(sample_lp)), 'folds': sample_lp},
                'RF': {'mean': float(np.mean(sample_rf)), 'std': float(np.std(sample_rf)), 'folds': sample_rf}},
            'participant_grouped_cv': {
                'FeatureMask_LP': {'mean': float(np.mean(group_lp)), 'std': float(np.std(group_lp)), 'folds': group_lp},
                'RF': {'mean': float(np.mean(group_rf)), 'std': float(np.std(group_rf)), 'folds': group_rf}}}
        print(f"  Sample-level:     LP={np.mean(sample_lp):.3f}±{np.std(sample_lp):.3f}  RF={np.mean(sample_rf):.3f}±{np.std(sample_rf):.3f}")
        print(f"  Participant-grouped: LP={np.mean(group_lp):.3f}±{np.std(group_lp):.3f}  RF={np.mean(group_rf):.3f}±{np.std(group_rf):.3f}")

    with open(f"{OUT_DIR}/A2_participant_grouped_cv.json", 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {OUT_DIR}/A2_participant_grouped_cv.json")
    return results

# ── A3: Inductive vs Transductive Evaluation ─────────────────────────────────
def run_inductive_evaluation(features, metadata, diseases=['CRC', 'IBD', 'T2D']):
    """
    Transductive: encoder pre-trained on all samples before CV.
    Inductive: encoder re-trained per fold on training samples only.
    """
    print("\n" + "=" * 70)
    print("A3: Inductive vs Transductive Evaluation")
    print("=" * 70)
    results = {}
    for disease in diseases:
        print(f"\n--- {disease} ---")
        X, y, _, _ = get_disease_subset(disease, features, metadata)
        print(f"  {len(X)} samples, {y.sum()} cases")

        print("  Transductive pretraining (all samples)...")
        enc_t, _ = pretrain_encoder(X, aug_type='feature_mask', epochs=150, verbose=True)
        emb_t = extract_embeddings(enc_t, X)

        skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        t_lp, i_lp, i_rf = [], [], []
        for fold, (tr, te) in enumerate(skf.split(X, y)):
            print(f"    Fold {fold+1}/5: inductive pretraining on {len(tr)} train samples...")
            enc_i, _ = pretrain_encoder(X[tr], aug_type='feature_mask', epochs=150)
            emb_i_tr = extract_embeddings(enc_i, X[tr])
            emb_i_te = extract_embeddings(enc_i, X[te])
            t_lp.append(evaluate_linear_probe(emb_t[tr], y[tr], emb_t[te], y[te]))
            i_lp.append(evaluate_linear_probe(emb_i_tr, y[tr], emb_i_te, y[te]))
            i_rf.append(evaluate_rf(X[tr], y[tr], X[te], y[te]))

        results[disease] = {
            'n_samples': len(X),
            'transductive': {'FeatureMask_LP': {'mean': float(np.mean(t_lp)), 'std': float(np.std(t_lp)), 'folds': t_lp}},
            'inductive': {
                'FeatureMask_LP': {'mean': float(np.mean(i_lp)), 'std': float(np.std(i_lp)), 'folds': i_lp},
                'RF': {'mean': float(np.mean(i_rf)), 'std': float(np.std(i_rf)), 'folds': i_rf}},
            'transductive_advantage': float(np.mean(t_lp) - np.mean(i_lp))}
        print(f"  Transductive LP: {np.mean(t_lp):.3f}±{np.std(t_lp):.3f}")
        print(f"  Inductive LP:    {np.mean(i_lp):.3f}±{np.std(i_lp):.3f}")
        print(f"  Inductive RF:    {np.mean(i_rf):.3f}±{np.std(i_rf):.3f}")

    with open(f"{OUT_DIR}/A3_inductive_evaluation.json", 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {OUT_DIR}/A3_inductive_evaluation.json")
    return results

# ── A5 / A6 verbatim from the original run ───────────────────────────────────
def run_mixup_alternatives(features, metadata, disease='CRC'):
    """
    Test alternative Mixup configurations:
    1. Standard Mixup (independent lambda) - baseline
    2. Same-lambda Mixup (both views use identical lambda)
    3. Mixup as fine-tuning regularizer (pretrain with FeatureMask, finetune with Mixup)
    """
    print("\n" + "=" * 70)
    print("A5: Mixup Alternative Configurations")
    print("=" * 70)

    X, y, subjects, sample_ids = get_disease_subset(disease, features, metadata)
    print(f"  {disease}: {len(X)} samples, {y.sum()} cases")

    results = {}
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # 1. Standard Mixup (independent lambda) - should fail like in IGC2
    print(f"\n  1. Standard Mixup (independent lambda)...")
    encoder_std, losses_std = pretrain_encoder(X, aug_type='mixup', epochs=150, verbose=True)
    emb_std = extract_embeddings(encoder_std, X)
    std_aurocs = []
    for train_idx, test_idx in skf.split(X, y):
        auroc = evaluate_linear_probe(emb_std[train_idx], y[train_idx], emb_std[test_idx], y[test_idx])
        std_aurocs.append(auroc)
    print(f"    Final loss: {losses_std[-1]:.4f}, AUROC: {np.mean(std_aurocs):.3f}±{np.std(std_aurocs):.3f}")
    results['standard_mixup'] = {
        'final_loss': float(losses_std[-1]),
        'auroc': {'mean': float(np.mean(std_aurocs)), 'std': float(np.std(std_aurocs)), 'folds': std_aurocs}}

    # 2. Same-lambda Mixup
    print(f"\n  2. Same-lambda Mixup (identical lambda for both views)...")
    encoder_same, losses_same = pretrain_encoder(X, aug_type='mixup_same_lambda', epochs=150, verbose=True)
    emb_same = extract_embeddings(encoder_same, X)
    same_aurocs = []
    for train_idx, test_idx in skf.split(X, y):
        auroc = evaluate_linear_probe(emb_same[train_idx], y[train_idx], emb_same[test_idx], y[test_idx])
        same_aurocs.append(auroc)
    print(f"    Final loss: {losses_same[-1]:.4f}, AUROC: {np.mean(same_aurocs):.3f}±{np.std(same_aurocs):.3f}")
    results['same_lambda_mixup'] = {
        'final_loss': float(losses_same[-1]),
        'auroc': {'mean': float(np.mean(same_aurocs)), 'std': float(np.std(same_aurocs)), 'folds': same_aurocs}}

    # 3. FeatureMask pretraining (baseline for comparison)
    print(f"\n  3. FeatureMask (baseline)...")
    encoder_fm, losses_fm = pretrain_encoder(X, aug_type='feature_mask', epochs=150, verbose=True)
    emb_fm = extract_embeddings(encoder_fm, X)
    fm_aurocs = []
    for train_idx, test_idx in skf.split(X, y):
        auroc = evaluate_linear_probe(emb_fm[train_idx], y[train_idx], emb_fm[test_idx], y[test_idx])
        fm_aurocs.append(auroc)
    print(f"    Final loss: {losses_fm[-1]:.4f}, AUROC: {np.mean(fm_aurocs):.3f}±{np.std(fm_aurocs):.3f}")
    results['feature_mask_baseline'] = {
        'final_loss': float(losses_fm[-1]),
        'auroc': {'mean': float(np.mean(fm_aurocs)), 'std': float(np.std(fm_aurocs)), 'folds': fm_aurocs}}

    with open(f"{OUT_DIR}/A5_mixup_alternatives.json", 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {OUT_DIR}/A5_mixup_alternatives.json")
    return results

# ── A6: RF on embeddings ──────────────────────────────────────────────────────
def run_rf_on_embeddings(features, metadata, diseases=['CRC', 'IBD', 'T2D']):
    """
    Compare: LP on embeddings vs RF on embeddings vs RF on original features.
    Isolates whether performance gap is due to embedding quality or classifier nonlinearity.
    """
    print("\n" + "=" * 70)
    print("A6: Linear vs Nonlinear Classifier on Embeddings")
    print("=" * 70)

    results = {}

    for disease in diseases:
        print(f"\n--- {disease} ---")
        X, y, subjects, sample_ids = get_disease_subset(disease, features, metadata)

        # Pretrain encoder (transductive)
        print(f"  Pretraining encoder (FeatureMask)...")
        encoder, _ = pretrain_encoder(X, aug_type='feature_mask', epochs=150, verbose=True)
        embeddings = extract_embeddings(encoder, X)

        skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        lp_aurocs, rf_emb_aurocs, rf_orig_aurocs = [], [], []

        for fold, (train_idx, test_idx) in enumerate(skf.split(X, y)):
            lp_aurocs.append(evaluate_linear_probe(
                embeddings[train_idx], y[train_idx], embeddings[test_idx], y[test_idx]))
            rf_emb_aurocs.append(evaluate_rf(
                embeddings[train_idx], y[train_idx], embeddings[test_idx], y[test_idx]))
            rf_orig_aurocs.append(evaluate_rf(
                X[train_idx], y[train_idx], X[test_idx], y[test_idx]))

        results[disease] = {
            'n_samples': len(X),
            'LP_on_embeddings': {'mean': float(np.mean(lp_aurocs)), 'std': float(np.std(lp_aurocs)), 'folds': lp_aurocs},
            'RF_on_embeddings': {'mean': float(np.mean(rf_emb_aurocs)), 'std': float(np.std(rf_emb_aurocs)), 'folds': rf_emb_aurocs},
            'RF_on_original': {'mean': float(np.mean(rf_orig_aurocs)), 'std': float(np.std(rf_orig_aurocs)), 'folds': rf_orig_aurocs}}

        print(f"  LP on embeddings:   {np.mean(lp_aurocs):.3f}±{np.std(lp_aurocs):.3f}")
        print(f"  RF on embeddings:   {np.mean(rf_emb_aurocs):.3f}±{np.std(rf_emb_aurocs):.3f}")
        print(f"  RF on original:     {np.mean(rf_orig_aurocs):.3f}±{np.std(rf_orig_aurocs):.3f}")
        print(f"  RF_emb - LP_emb:    {np.mean(rf_emb_aurocs)-np.mean(lp_aurocs):.3f} (nonlinearity effect)")
        print(f"  RF_orig - RF_emb:   {np.mean(rf_orig_aurocs)-np.mean(rf_emb_aurocs):.3f} (embedding quality effect)")

    with open(f"{OUT_DIR}/A6_rf_on_embeddings.json", 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {OUT_DIR}/A6_rf_on_embeddings.json")
    return results

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    device = 'cpu'
    print(f"Device: {device}")
    print(f"PyTorch: {torch.__version__}")

    # Run all analyses
    a2_results = run_participant_grouped_cv(features_df, metadata_df)
    a3_results = run_inductive_evaluation(features_df, metadata_df)
    a5_results = run_mixup_alternatives(features_df, metadata_df)
    a6_results = run_rf_on_embeddings(features_df, metadata_df)

    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY OF ALL ANALYSES")
    print("=" * 70)

    print("\nA2: Participant-Grouped CV")
    for d, r in a2_results.items():
        s_lp = r['sample_level_cv']['FeatureMask_LP']['mean']
        g_lp = r['participant_grouped_cv']['FeatureMask_LP']['mean']
        s_rf = r['sample_level_cv']['RF']['mean']
        g_rf = r['participant_grouped_cv']['RF']['mean']
        print(f"  {d}: Sample LP={s_lp:.3f} RF={s_rf:.3f} | Grouped LP={g_lp:.3f} RF={g_rf:.3f}")

    print("\nA3: Inductive vs Transductive")
    for d, r in a3_results.items():
        t_lp = r['transductive']['FeatureMask_LP']['mean']
        i_lp = r['inductive']['FeatureMask_LP']['mean']
        i_rf = r['inductive']['RF']['mean']
        print(f"  {d}: Trans LP={t_lp:.3f} | Ind LP={i_lp:.3f} RF={i_rf:.3f} | Adv={r['transductive_advantage']:.3f}")

    print("\nA5: Mixup Alternatives (CRC)")
    for k, r in a5_results.items():
        print(f"  {k}: loss={r['final_loss']:.4f} AUROC={r['auroc']['mean']:.3f}±{r['auroc']['std']:.3f}")

    print("\nA6: RF on Embeddings")
    for d, r in a6_results.items():
        print(f"  {d}: LP_emb={r['LP_on_embeddings']['mean']:.3f} RF_emb={r['RF_on_embeddings']['mean']:.3f} RF_orig={r['RF_on_original']['mean']:.3f}")

    print("\nAll analyses complete!")
