
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.lines import Line2D

DATA_DIR   = "/mnt/shared-workspace/microclr_data"
RESULT_DIR = f"{DATA_DIR}/results"

# ── Load data ──────────────────────────────────────────────────────────────────
ll_lp  = pd.read_csv(f"{RESULT_DIR}/lowlabel_results.csv")
ft_cv  = pd.read_csv(f"{RESULT_DIR}/ft_cv_results.csv")
ft_ll  = pd.read_csv(f"{RESULT_DIR}/ft_lowlabel_results.csv")

# ── Harmonise method names ─────────────────────────────────────────────────────
lp_rename = {
    "MicroCLR-PhyloAug":    "PhyloAug (LP)",
    "MicroCLR-FeatureMask": "FeatureMask (LP)",
    "MicroCLR-GaussianNoise":"GaussianNoise (LP)",
    "MicroCLR-TaxDropAug":  "TaxDropAug (LP)",
    "MicroCLR-CompAug":     "CompAug (LP)",
    "RF":                   "RF",
    "LogReg":               "LogReg",
}
ll_lp["method"] = ll_lp["method"].map(lp_rename)

# ── Build summary tables ───────────────────────────────────────────────────────
def summarise(df, frac_col="frac"):
    return df.groupby(["disease","method",frac_col])["AUROC"].agg(
        mean="mean", std="std", n="count"
    ).reset_index().rename(columns={frac_col:"frac"})

lp_sum  = summarise(ll_lp)
ft_sum  = summarise(ft_ll)

# 100% FT from ft_cv (mean across 5 folds)
ft_100 = ft_cv.groupby(["disease","method"])["AUROC"].agg(mean="mean",std="std",n="count").reset_index()
ft_100["frac"] = 1.0
ft_sum = pd.concat([ft_sum, ft_100], ignore_index=True)

# 100% LP from ll_lp (already has frac=1.0)
# already in lp_sum

# ── Colour / style maps ────────────────────────────────────────────────────────
AUG_NAMES = ["PhyloAug","CompAug","TaxDropAug","FeatureMask","GaussianNoise"]

# FT lines: warm reds/oranges
ft_colors = {
    "PhyloAug (FT)":     "#D62728",
    "CompAug (FT)":      "#FF7F0E",
    "TaxDropAug (FT)":   "#E377C2",
    "FeatureMask (FT)":  "#9467BD",
    "GaussianNoise (FT)":"#8C564B",
    "MLP-RandomInit":    "#2CA02C",
}
# LP lines: cool blues
lp_colors = {
    "PhyloAug (LP)":     "#AEC7E8",
    "CompAug (LP)":      "#FFBB78",
    "TaxDropAug (LP)":   "#F7B6D2",
    "FeatureMask (LP)":  "#C5B0D5",
    "GaussianNoise (LP)":"#C49C94",
}
ref_colors = {"RF": "#000000", "LogReg": "#555555"}

FRACS_PLOT = [0.10, 0.25, 0.50, 1.0]
DISEASES   = ["CRC", "T2D", "IBD"]
DISEASE_LABELS = {"CRC":"Colorectal Cancer (CRC)",
                  "T2D":"Type 2 Diabetes (T2D)",
                  "IBD":"Inflammatory Bowel Disease (IBD)"}

fig, axes = plt.subplots(1, 3, figsize=(16, 5), sharey=False)

for ax, disease in zip(axes, DISEASES):
    # ── FT lines ──
    for method, color in ft_colors.items():
        sub = ft_sum[(ft_sum["disease"]==disease) & (ft_sum["method"]==method)]
        sub = sub.sort_values("frac")
        if sub.empty: continue
        ls = "-" if method != "MLP-RandomInit" else "--"
        lw = 2.0 if method != "MLP-RandomInit" else 2.2
        ax.plot(sub["frac"], sub["mean"], color=color, ls=ls, lw=lw,
                marker="o", ms=5, zorder=3)
        ax.fill_between(sub["frac"],
                        sub["mean"]-sub["std"], sub["mean"]+sub["std"],
                        color=color, alpha=0.08)

    # ── LP lines (dashed, thinner) ──
    for method, color in lp_colors.items():
        sub = lp_sum[(lp_sum["disease"]==disease) & (lp_sum["method"]==method)]
        sub = sub.sort_values("frac")
        if sub.empty: continue
        ax.plot(sub["frac"], sub["mean"], color=color, ls=":", lw=1.5,
                marker="s", ms=4, zorder=2)

    # ── Reference lines (RF, LogReg) ──
    for method, color in ref_colors.items():
        sub = lp_sum[(lp_sum["disease"]==disease) & (lp_sum["method"]==method)]
        sub = sub.sort_values("frac")
        if sub.empty: continue
        ax.plot(sub["frac"], sub["mean"], color=color, ls="-.", lw=1.8,
                marker="^", ms=5, zorder=4)

    ax.set_title(DISEASE_LABELS[disease], fontsize=11, fontweight="bold")
    ax.set_xlabel("Labeled fraction", fontsize=10)
    ax.set_ylabel("AUROC" if ax == axes[0] else "", fontsize=10)
    ax.set_xticks(FRACS_PLOT)
    ax.set_xticklabels(["10%","25%","50%","100%"])
    ax.set_xlim(0.05, 1.05)
    ax.grid(True, alpha=0.3, ls="--")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

# ── Legend ──
legend_elements = []
for method, color in ft_colors.items():
    ls = "-" if method != "MLP-RandomInit" else "--"
    legend_elements.append(Line2D([0],[0], color=color, ls=ls, lw=2,
                                   marker="o", ms=5, label=method))
for method, color in lp_colors.items():
    legend_elements.append(Line2D([0],[0], color=color, ls=":", lw=1.5,
                                   marker="s", ms=4, label=method))
for method, color in ref_colors.items():
    legend_elements.append(Line2D([0],[0], color=color, ls="-.", lw=1.8,
                                   marker="^", ms=5, label=method))

fig.legend(handles=legend_elements, loc="lower center", ncol=5,
           fontsize=8, frameon=True, bbox_to_anchor=(0.5, -0.18))

fig.suptitle("Low-Label Learning Curves: Fine-Tuning vs Linear Probe",
             fontsize=13, fontweight="bold", y=1.01)
plt.tight_layout()

for ext in ["png","svg"]:
    path = f"/mnt/results/fig7_lowlabel_finetuning.{ext}"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    print(f"Saved {path}")
plt.close()

# ── Print summary table (10% labels) ──────────────────────────────────────────
print("\n=== AUROC at 10% labels ===")
rows = []
for disease in DISEASES:
    for method in list(ft_colors.keys()) + list(lp_colors.keys()) + list(ref_colors.keys()):
        if method in ft_colors:
            sub = ft_sum[(ft_sum["disease"]==disease) & (ft_sum["method"]==method) & (ft_sum["frac"]==0.10)]
        else:
            sub = lp_sum[(lp_sum["disease"]==disease) & (lp_sum["method"]==method) & (lp_sum["frac"]==0.10)]
        if sub.empty: continue
        rows.append({"disease":disease,"method":method,
                     "AUROC_10pct": sub["mean"].values[0],
                     "SD_10pct":    sub["std"].values[0]})
tbl = pd.DataFrame(rows)
print(tbl.pivot(index="method", columns="disease", values="AUROC_10pct").round(3).to_string())

# Save table
tbl.to_csv(f"{RESULT_DIR}/lowlabel_10pct_summary.csv", index=False)
print("\nTable saved.")
