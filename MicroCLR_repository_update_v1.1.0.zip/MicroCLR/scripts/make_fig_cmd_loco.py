#!/usr/bin/env python3
"""
Regenerate CMD LOCO figures (manuscript Figures 3 and 4) for the MicroCLR
second-round revision (BIOADV-2026-484).

Fixes raised by Reviewer 2 / Editorial Mandatory comment 3:
  - Removes TemporalAug / TemporalStab / TemporalTraj (companion-paper methods
    never described in this manuscript) and MixAug (excluded per text).
  - Uses manuscript-consistent method names.
  - Larger fonts, colorbar outside the heatmap panels.
  - Highlights the best MicroCLR model per disease in the bar chart.
  - Defines every label in the captions (see manuscript).

Data source: per-split LOCO AUROCs recovered from the original evaluation log
(cmd_loco_parsed.json), cross-validated against the manuscript-reported means
(FeatureMask CRC 0.724+-0.085, IBD 0.766+-0.043; ComboAug T2D 0.664+-0.056).
RF baseline mean+-SD from the manuscript text.

Palette (harmonized across all paper figures, Reviewer 3):
  blue  #0279EE = MicroCLR variants   gray #8C8C8C = RawCLR (no augmentation)
  orange #FF9400 = Random Forest baseline
"""

import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import matplotlib as mpl

mpl.rcParams['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
mpl.rcParams['svg.fonttype'] = 'none'

with open('/workspace/work/cmd_loco_parsed.json') as f:
    data = json.load(f)

# Manuscript-consistent names
RENAME = {'GaussNoise': 'GaussianNoise', 'EcoAug': 'EcologicalAug',
          'CohortStyle': 'CohortStyleAug'}
for old, new in RENAME.items():
    data[new] = data.pop(old)

ROWS = ['RawCLR', 'GaussianNoise', 'FeatureMask', 'Subsample',
        'PhyloAug', 'EcologicalAug', 'CohortStyleAug', 'ComboAug']
DISEASES = ['CRC', 'IBD', 'T2D']
COHORTS = {
    'CRC': ['FengQ_2015', 'HanniganGD_2017', 'ThomasAM_2018a', 'ThomasAM_2018b',
            'VogtmannE_2016', 'WirbelJ_2018', 'YachidaS_2019', 'YuJ_2015', 'ZellerG_2014'],
    'IBD': ['HMP_2019_ibdmdb', 'HallAB_2017', 'NielsenHB_2014'],
    'T2D': ['KarlssonFH_2013', 'MetaCardis_2020_a', 'QinJ_2012'],
}
RF = {'CRC': (0.756, 0.119), 'IBD': (0.778, 0.042), 'T2D': (0.644, 0.084)}

BLUE, GRAY, ORANGE = '#0279EE', '#8C8C8C', '#FF9400'

# ── Matrix ───────────────────────────────────────────────────────────────────
cols = [(d, c) for d in DISEASES for c in COHORTS[d]]
M = np.array([[data[m][d][c] for (d, c) in cols] for m in ROWS])

# sanity checks vs manuscript text (ddof=1)
fm_crc = M[ROWS.index('FeatureMask'), :9]
assert abs(fm_crc.mean() - 0.724) < 0.001 and abs(fm_crc.std(ddof=1) - 0.085) < 0.002, fm_crc
ca_t2d = M[ROWS.index('ComboAug'), 12:]
assert abs(ca_t2d.mean() - 0.664) < 0.001, ca_t2d
print("Sanity checks passed: FeatureMask CRC and ComboAug T2D match text.")

# HanniganGD outlier mean across the 7 augmentations (excluding RawCLR baseline)
hg_idx = cols.index(('CRC', 'HanniganGD_2017'))
hg_aug_mean = M[1:, hg_idx].mean()
hg_all_mean = M[:, hg_idx].mean()
print(f"HanniganGD_2017 mean: across 7 augmentations = {hg_aug_mean:.3f}, "
      f"across all 8 rows = {hg_all_mean:.3f}")

# ── Figure 3: heatmap ────────────────────────────────────────────────────────
fig = plt.figure(figsize=(11, 4.6))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 0.02], wspace=0.06)
ax = fig.add_subplot(gs[0, 0])
cax = fig.add_subplot(gs[0, 1])

im = ax.imshow(M, cmap='RdYlGn', vmin=0.3, vmax=0.9, aspect='auto')
ax.set_xticks(range(len(cols)))
ax.set_xticklabels([c for (d, c) in cols], rotation=45, ha='right', fontsize=10)
ax.set_yticks(range(len(ROWS)))
ax.set_yticklabels(ROWS, fontsize=11)
for i in range(len(ROWS)):
    for j in range(len(cols)):
        v = M[i, j]
        ax.text(j, i, f"{v:.2f}", ha='center', va='center', fontsize=9,
                color='black' if 0.42 < v < 0.78 else 'white')

# disease group separators + headers (above the heatmap, inside the axes)
bounds = [0, 9, 12, 15]
for b in bounds[1:-1]:
    ax.axvline(b - 0.5, color='black', linewidth=1.6)
for d, s, e in [('CRC', 0, 9), ('IBD', 9, 12), ('T2D', 12, 15)]:
    ax.text((s + e - 1) / 2, -0.85, d, fontsize=12, fontweight='bold',
            ha='center', va='bottom')

# HanniganGD outlier marker
ax.add_patch(Rectangle((hg_idx - 0.5, -0.5), 1, len(ROWS), fill=False,
                       edgecolor='black', linewidth=1.8, linestyle=':'))

cb = fig.colorbar(im, cax=cax)
cb.set_label('AUROC', fontsize=11)
cb.ax.tick_params(labelsize=10)

ax.set_title('CMD leave-one-cohort-out AUROC', fontsize=13, pad=22)
fig.tight_layout()
fig.savefig('/workspace/work/fig_loco_heatmap_cmd_v4.png', dpi=300, bbox_inches='tight')
fig.savefig('/workspace/work/fig_loco_heatmap_cmd_v4.svg', bbox_inches='tight')
plt.close(fig)
print("Saved fig_loco_heatmap_cmd_v4.png/.svg")

# ── Figure 4: bar chart ──────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(13, 4.2), sharey=False)
best_per_disease = {}
for k, d in enumerate(DISEASES):
    ax = axes[k]
    sl = slice(*({'CRC': (0, 9), 'IBD': (9, 12), 'T2D': (12, 15)}[d]))
    means = M[:, sl].mean(axis=1)
    sds = M[:, sl].std(axis=1, ddof=1)

    colors = [GRAY if m == 'RawCLR' else BLUE for m in ROWS]
    bars = ax.bar(range(len(ROWS)), means, yerr=sds, capsize=3,
                  color=colors, edgecolor='black', linewidth=0.6, width=0.72)
    # highlight best MicroCLR (non-RawCLR) per disease
    bi = int(np.argmax(np.where(np.array(ROWS) != 'RawCLR', means, -1)))
    bars[bi].set_edgecolor('black')
    bars[bi].set_linewidth(2.2)
    best_per_disease[d] = (ROWS[bi], means[bi], sds[bi])

    rf_m, rf_s = RF[d]
    ax.axhline(rf_m, color=ORANGE, linestyle='--', linewidth=1.8,
               label='Random Forest')
    ax.axhspan(rf_m - rf_s, rf_m + rf_s, color=ORANGE, alpha=0.13, linewidth=0)

    ax.set_xticks(range(len(ROWS)))
    ax.set_xticklabels(ROWS, rotation=45, ha='right', fontsize=9)
    ax.set_ylim(0.3, 1.0)
    ax.axhline(0.5, color='black', linewidth=0.7, linestyle=':')
    if k == 0:
        ax.set_ylabel('LOCO AUROC (mean ± SD)', fontsize=11)
    ax.set_title(f'{d} ({ {"CRC": 9, "IBD": 3, "T2D": 3}[d] } cohorts)', fontsize=12)
    if k == 0:
        ax.legend(loc='upper left', fontsize=9, frameon=False)

fig.tight_layout()
fig.savefig('/workspace/work/fig_loco_bar_cmd_v4.png', dpi=300, bbox_inches='tight')
fig.savefig('/workspace/work/fig_loco_bar_cmd_v4.svg', bbox_inches='tight')
plt.close(fig)
print("Saved fig_loco_bar_cmd_v4.png/.svg")
for d, (m, mu, sd) in best_per_disease.items():
    print(f"  best {d}: {m} {mu:.3f}±{sd:.3f}")
