"""
pretrain.py — MicroCLR self-supervised pre-training
====================================================
Pre-trains a 3-layer MLP encoder using NT-Xent contrastive loss
with a chosen augmentation strategy.

Usage:
    python scripts/pretrain.py \
        --features  data/features_clr_verified.csv.gz \
        --meta      data/metadata_verified.csv \
        --aug       EcologicalAug \
        --outdir    models/ \
        --epochs    150 \
        --batch     128 \
        --lr        3e-4

Supported augmentations:
    PhyloAug, CompAug, TaxDropAug, FeatureMask,
    GaussianNoise, MixupAug, EcologicalAug, CohortStyleAug
"""

import argparse
import json
import pickle
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset


# ── Architecture ──────────────────────────────────────────────────────────────

class MicroCLREncoder(nn.Module):
    def __init__(self, input_dim=426):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Linear(256, 128),
        )

    def forward(self, x):
        return self.encoder(x)


class ProjectionHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
        )

    def forward(self, x):
        return self.head(x)


# ── NT-Xent Loss ──────────────────────────────────────────────────────────────

def nt_xent_loss(z1, z2, temperature=0.07):
    """NT-Xent (normalized temperature-scaled cross-entropy) loss."""
    z1 = nn.functional.normalize(z1, dim=1)
    z2 = nn.functional.normalize(z2, dim=1)
    N = z1.size(0)
    z = torch.cat([z1, z2], dim=0)                          # (2N, D)
    sim = torch.mm(z, z.T) / temperature                    # (2N, 2N)
    # Mask self-similarity
    mask = torch.eye(2 * N, dtype=torch.bool, device=z.device)
    sim.masked_fill_(mask, float("-inf"))
    # Positive pairs: (i, i+N) and (i+N, i)
    labels = torch.cat([torch.arange(N, 2 * N), torch.arange(N)]).to(z.device)
    loss = nn.functional.cross_entropy(sim, labels)
    return loss


# ── Dataset ───────────────────────────────────────────────────────────────────

class AugmentedDataset(torch.utils.data.Dataset):
    def __init__(self, X, sample_ids, aug):
        self.X = X
        self.sample_ids = sample_ids
        self.aug = aug

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        x = self.X[idx]
        sid = self.sample_ids[idx]
        x1 = self.aug(x.copy(), sample_id=sid) if hasattr(self.aug, '_needs_sid') else self.aug(x.copy())
        x2 = self.aug(x.copy(), sample_id=sid) if hasattr(self.aug, '_needs_sid') else self.aug(x.copy())
        return torch.tensor(x1, dtype=torch.float32), torch.tensor(x2, dtype=torch.float32)


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", default="data/features_clr_verified.csv.gz")
    parser.add_argument("--meta",     default="data/metadata_verified.csv")
    parser.add_argument("--aug",      default="EcologicalAug",
                        choices=["PhyloAug","CompAug","TaxDropAug","FeatureMask",
                                 "GaussianNoise","MixupAug","EcologicalAug","CohortStyleAug"])
    parser.add_argument("--outdir",   default="models/")
    parser.add_argument("--epochs",   type=int,   default=150)
    parser.add_argument("--batch",    type=int,   default=128)
    parser.add_argument("--lr",       type=float, default=3e-4)
    parser.add_argument("--tau",      type=float, default=0.07)
    parser.add_argument("--seed",     type=int,   default=42)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # Load data
    print("Loading data...")
    feat_df = pd.read_csv(args.features, index_col=0)
    meta_df = pd.read_csv(args.meta).set_index("sample_id")
    common  = feat_df.index.intersection(meta_df.index)
    feat_df = feat_df.loc[common]
    meta_df = meta_df.loc[common]
    X = feat_df.values.astype(np.float32)
    sample_ids = list(feat_df.index)
    print(f"  {X.shape[0]} samples × {X.shape[1]} features")

    # Build augmentation
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from augmentations.augmentations_v2 import (
        PhyloAug, CompAug, TaxDropAug, FeatureMask,
        GaussianNoise, MixupAug, EcologicalAug, CohortStyleAug
    )

    aug_kwargs = {}
    if args.aug == "PhyloAug":
        with open("data/clade_groups.json") as f:
            clade_groups = json.load(f)
        aug = PhyloAug(clade_groups=clade_groups, seed=args.seed)
    elif args.aug == "CompAug":
        aug = CompAug(seed=args.seed)
    elif args.aug == "TaxDropAug":
        aug = TaxDropAug(seed=args.seed)
    elif args.aug == "FeatureMask":
        aug = FeatureMask(seed=args.seed)
    elif args.aug == "GaussianNoise":
        aug = GaussianNoise(seed=args.seed)
    elif args.aug == "MixupAug":
        aug = MixupAug(X=X, seed=args.seed)
    elif args.aug == "EcologicalAug":
        with open("data/cooccurrence_network.pkl", "rb") as f:
            network = pickle.load(f)
        aug = EcologicalAug(
            pos_neighbors=network["pos_neighbors"],
            neg_neighbors=network["neg_neighbors"],
            k_seeds_range=(1, 5),
            alpha_range=(0.1, 0.4),
            seed=args.seed,
        )
    elif args.aug == "CohortStyleAug":
        cohort_means   = np.load("data/cohort_means.npy", allow_pickle=True).item()
        sample_cohorts = dict(zip(sample_ids, meta_df["cohort"].tolist()))
        aug = CohortStyleAug(
            cohort_means=cohort_means,
            sample_cohorts=sample_cohorts,
            beta_max=0.5,
            noise_std=0.05,
            seed=args.seed,
        )

    # Dataset + loader
    dataset = AugmentedDataset(X, sample_ids, aug)
    loader  = DataLoader(dataset, batch_size=args.batch, shuffle=True,
                         drop_last=True, num_workers=0)

    # Model
    encoder    = MicroCLREncoder(input_dim=X.shape[1]).to(device)
    projector  = ProjectionHead().to(device)
    optimizer  = torch.optim.Adam(
        list(encoder.parameters()) + list(projector.parameters()),
        lr=args.lr, weight_decay=1e-4
    )
    scheduler  = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    # Training loop
    import os
    os.makedirs(args.outdir, exist_ok=True)
    losses = []
    best_loss = float("inf")
    print(f"Pre-training {args.aug} for {args.epochs} epochs...")
    for epoch in range(1, args.epochs + 1):
        encoder.train(); projector.train()
        epoch_loss = 0.0
        for x1, x2 in loader:
            x1, x2 = x1.to(device), x2.to(device)
            z1 = projector(encoder(x1))
            z2 = projector(encoder(x2))
            loss = nt_xent_loss(z1, z2, temperature=args.tau)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
        epoch_loss /= len(loader)
        losses.append(epoch_loss)
        scheduler.step()
        if epoch_loss < best_loss:
            best_loss = epoch_loss
        if epoch % 10 == 0:
            print(f"  Epoch {epoch:3d}/{args.epochs}  loss={epoch_loss:.4f}  best={best_loss:.4f}")

    # Save checkpoint
    out_path = os.path.join(args.outdir, f"microclr_{args.aug}.pt")
    torch.save({
        "encoder_state_dict":   encoder.state_dict(),
        "projector_state_dict": projector.state_dict(),
        "losses": losses,
        "args":   vars(args),
    }, out_path)
    print(f"\nSaved checkpoint: {out_path}")
    print(f"Final loss: {losses[-1]:.4f}  |  Min loss: {min(losses):.4f}")

    # Save loss curve
    loss_path = os.path.join(args.outdir, f"losses_{args.aug}.json")
    with open(loss_path, "w") as f:
        json.dump(losses, f)
    print(f"Saved loss curve: {loss_path}")


if __name__ == "__main__":
    main()
