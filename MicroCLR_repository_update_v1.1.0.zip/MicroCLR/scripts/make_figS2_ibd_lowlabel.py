#!/usr/bin/env python3
"""Supplementary Figure S2: exploratory IBD low-label learning curves (IGC2/HGMA).

Same series/style as main-text Figure 5 (fig4_lowlabel_curves_v2) for
cross-figure consistency (R3): PhyloAug blue, FeatureMask pink, GaussianNoise
yellow, Random Forest black dashed, LogReg gray dotted. IBD data are the
exploratory results (potential participant leakage; main text Section 3.13).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

matplotlib.rcParams["svg.fonttype"] = "none"
matplotlib.rcParams["font.family"] = ["Liberation Sans", "Arimo", "DejaVu Sans"]

EV = "/workspace/repo_extract/MicroCLR/evaluation"
OUT = "/workspace/work"
ll = pd.read_csv(f"{EV}/lowlabel_results.csv")
ibd = ll[ll.disease == "IBD"]
fracs = [0.1, 0.25, 0.5, 1.0]
xticks = ["10%", "25%", "50%", "100%"]
series = [
    ("MicroCLR-PhyloAug", "#0279EE", "-", "o", "MicroCLR-PhyloAug (LP)"),
    ("MicroCLR-FeatureMask", "#FD9BED", "-", "o", "MicroCLR-FeatureMask (LP)"),
    ("MicroCLR-GaussianNoise", "#E9ED4C", "-", "o", "MicroCLR-GaussianNoise (LP)"),
    ("RF", "black", "--", "o", "Random Forest"),
    ("LogReg", "gray", ":", "o", "Logistic Regression"),
]
fig, ax = plt.subplots(figsize=(6.4, 4.6))
x = np.arange(len(fracs))
for method, color, ls, marker, label in series:
    means = [ibd[(ibd.method == method) & (ibd.frac == f)].AUROC.mean() for f in fracs]
    sds = [ibd[(ibd.method == method) & (ibd.frac == f)].AUROC.std(ddof=1) for f in fracs]
    ax.plot(x, means, ls, color=color, marker=marker, markersize=6, linewidth=2, label=label)
    ax.fill_between(x, np.array(means) - np.array(sds), np.array(means) + np.array(sds),
                    color=color, alpha=0.15, linewidth=0)
ax.set_xticks(x, xticks)
ax.set_xlabel("Labeled data (%)", fontsize=11)
ax.set_ylabel("AUROC", fontsize=11)
ax.set_title("Exploratory IBD Low-Label Regime (IGC2/HGMA)",
             fontsize=12, fontweight="bold")
ax.legend(fontsize=8.5, loc="lower right", framealpha=0.9)
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(f"{OUT}/figS2_lowlabel_ibd_v2.png", dpi=300, bbox_inches="tight")
fig.savefig(f"{OUT}/figS2_lowlabel_ibd_v2.svg", bbox_inches="tight")
plt.close(fig)
print("saved figS2_lowlabel_ibd_v2.png/.svg")
