"""
evaluate_lp.py — MicroCLR linear probe evaluation
==================================================
Evaluates a pre-trained encoder via logistic regression linear probe
under two protocols: within-cohort 5-fold CV and LOCO.

Usage:
    python scripts/evaluate_lp.py \
        --features  data/features_clr_verified.csv.gz \
        --meta      data/metadata_verified.csv \
        --cv_splits data/cv_splits_verified.json \
        --loco_splits data/loco_splits_verified.json \
        --model     models/microclr_EcologicalAug.pt \
        --aug_name  EcologicalAug \
        --outdir    evaluation/
"""

import argparse
import json
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler


class MicroCLREncoder(nn.Module):
    def __init__(self, input_dim=426):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Linear(256, 128),
        )

    def forward(self, x):
        return self.encoder(x)


def load_encoder(model_path, input_dim=426):
    model = MicroCLREncoder(input_dim=input_dim)
    ckpt  = torch.load(model_path, map_location="cpu")
    model.load_state_dict(ckpt["encoder_state_dict"])
    model.eval()
    return model


def get_embeddings(model, X):
    with torch.no_grad():
        emb = model(torch.tensor(X, dtype=torch.float32))
    return emb.numpy()


def linear_probe(emb_train, y_train, emb_test, y_test):
    scaler = StandardScaler()
    emb_train = scaler.fit_transform(emb_train)
    emb_test  = scaler.transform(emb_test)
    clf = LogisticRegression(max_iter=1000, C=1.0, solver="lbfgs")
    clf.fit(emb_train, y_train)
    proba = clf.predict_proba(emb_test)[:, 1]
    return roc_auc_score(y_test, proba)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--features",    default="data/features_clr_verified.csv.gz")
    parser.add_argument("--meta",        default="data/metadata_verified.csv")
    parser.add_argument("--cv_splits",   default="data/cv_splits_verified.json")
    parser.add_argument("--loco_splits", default="data/loco_splits_verified.json")
    parser.add_argument("--model",       required=True)
    parser.add_argument("--aug_name",    required=True)
    parser.add_argument("--outdir",      default="evaluation/")
    args = parser.parse_args()

    import os
    os.makedirs(args.outdir, exist_ok=True)

    # Load data
    feat_df = pd.read_csv(args.features, index_col=0)
    meta_df = pd.read_csv(args.meta).set_index("sample_id")
    common  = feat_df.index.intersection(meta_df.index)
    feat_df = feat_df.loc[common]
    meta_df = meta_df.loc[common]
    X = feat_df.values.astype(np.float32)
    sample_ids = list(feat_df.index)
    sid_to_idx = {s: i for i, s in enumerate(sample_ids)}

    # Load encoder
    model = load_encoder(args.model, input_dim=X.shape[1])
    emb   = get_embeddings(model, X)

    # ── Within-cohort CV ──────────────────────────────────────────────────────
    with open(args.cv_splits) as f:
        cv_splits = json.load(f)

    cv_rows = []
    for disease, folds in cv_splits.items():
        disease_meta = meta_df[meta_df["disease"] == disease]
        for fold_id, split in folds.items():
            train_idx = [sid_to_idx[s] for s in split["train"] if s in sid_to_idx]
            test_idx  = [sid_to_idx[s] for s in split["test"]  if s in sid_to_idx]
            y_train   = meta_df.loc[[sample_ids[i] for i in train_idx], "label"].values
            y_test    = meta_df.loc[[sample_ids[i] for i in test_idx],  "label"].values
            if len(np.unique(y_test)) < 2:
                continue
            auroc = linear_probe(emb[train_idx], y_train, emb[test_idx], y_test)
            cv_rows.append({"method": f"MicroCLR-{args.aug_name}", "disease": disease,
                            "fold": fold_id, "auroc": auroc, "protocol": "cv"})
            print(f"  CV  {disease} fold {fold_id}: AUROC={auroc:.4f}")

    # ── LOCO ──────────────────────────────────────────────────────────────────
    with open(args.loco_splits) as f:
        loco_splits = json.load(f)

    loco_rows = []
    for disease, cohorts in loco_splits.items():
        for held_out, split in cohorts.items():
            train_idx = [sid_to_idx[s] for s in split["train"] if s in sid_to_idx]
            test_idx  = [sid_to_idx[s] for s in split["test"]  if s in sid_to_idx]
            y_train   = meta_df.loc[[sample_ids[i] for i in train_idx], "label"].values
            y_test    = meta_df.loc[[sample_ids[i] for i in test_idx],  "label"].values
            if len(np.unique(y_test)) < 2:
                continue
            auroc = linear_probe(emb[train_idx], y_train, emb[test_idx], y_test)
            loco_rows.append({"method": f"MicroCLR-{args.aug_name}", "disease": disease,
                              "held_out_cohort": held_out, "auroc": auroc, "protocol": "loco"})
            print(f"  LOCO {disease} held-out={held_out}: AUROC={auroc:.4f}")

    # Save
    import csv
    all_rows = cv_rows + loco_rows
    out_csv = os.path.join(args.outdir, f"lp_results_{args.aug_name}.csv")
    keys = ["method", "disease", "fold", "held_out_cohort", "auroc", "protocol"]
    with open(out_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)
    print(f"\nSaved: {out_csv}")


if __name__ == "__main__":
    main()
