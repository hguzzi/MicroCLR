"""
MicroCLR Augmentation Library — v3 (novel augmentations)
=========================================================
Adds two novel biologically-inspired augmentations:

  EcologicalAug   — ecologically-constrained community perturbation
                    Uses Spearman co-occurrence network to propagate
                    taxon dropout through ecological relationships
                    (cross-feeding / competitive exclusion)

  CohortStyleAug  — inter-cohort technical variation simulation
                    Applies partial cohort mean-shift transfer to
                    simulate batch effects between cohorts

All existing augmentations from v2 are preserved unchanged.
"""

import numpy as np
import json
import pickle
import os


# ─────────────────────────────────────────────────────────────────────────────
# Existing augmentations (unchanged from v2)
# ─────────────────────────────────────────────────────────────────────────────

class PhyloAug:
    def __init__(self, clade_groups, p_clade=0.20, p_taxon=0.10, seed=None):
        self.name = "PhyloAug"
        self.clade_groups = clade_groups
        self.clade_list = list(clade_groups.values())
        self.p_clade = p_clade
        self.p_taxon = p_taxon
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        x_aug = x.copy()
        for idxs in self.clade_list:
            idxs = np.array(idxs)
            if self.rng.random() < self.p_clade:
                x_aug[idxs] = 0.0
            else:
                mask = self.rng.random(len(idxs)) < self.p_taxon
                x_aug[idxs[mask]] = 0.0
        nz = x_aug != 0
        if nz.sum() > 0:
            x_aug[nz] -= x_aug[nz].mean()
        return x_aug


class CompAug:
    def __init__(self, noise_std=0.15, seed=None):
        self.name = "CompAug"
        self.noise_std = noise_std
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        noise = self.rng.normal(0, self.noise_std, size=x.shape)
        x_aug = x + noise
        x_aug = x_aug - x_aug.mean()
        return x_aug


class TaxDropAug:
    def __init__(self, drop_fraction=0.20, low_abundance_quantile=0.40, seed=None):
        self.name = "TaxDropAug"
        self.drop_fraction = drop_fraction
        self.low_abundance_quantile = low_abundance_quantile
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        x_aug = x.copy()
        threshold = np.quantile(x, self.low_abundance_quantile)
        low_idx = np.where(x <= threshold)[0]
        n_drop = max(1, int(len(low_idx) * self.drop_fraction))
        drop_idx = self.rng.choice(low_idx, size=n_drop, replace=False)
        x_aug[drop_idx] = 0.0
        nz = x_aug != 0
        if nz.sum() > 0:
            x_aug[nz] -= x_aug[nz].mean()
        return x_aug


class FeatureMask:
    def __init__(self, mask_fraction=0.30, seed=None):
        self.name = "FeatureMask"
        self.mask_fraction = mask_fraction
        self.feature_marginals = None
        self.rng = np.random.default_rng(seed)

    def set_marginals(self, X):
        self.feature_marginals = X

    def __call__(self, x):
        x_aug = x.copy()
        n = len(x)
        n_mask = max(1, int(n * self.mask_fraction))
        mask_idx = self.rng.choice(n, size=n_mask, replace=False)
        if self.feature_marginals is not None:
            for idx in mask_idx:
                x_aug[idx] = self.rng.choice(self.feature_marginals[:, idx])
        else:
            x_aug[mask_idx] = 0.0
        return x_aug


class GaussianNoise:
    def __init__(self, noise_std=0.15, seed=None):
        self.name = "GaussianNoise"
        self.noise_std = noise_std
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        return x + self.rng.normal(0, self.noise_std, size=x.shape)


class MixupAug:
    def __init__(self, alpha=0.2, seed=None):
        self.name = "MixupAug"
        self.alpha = alpha
        self.dataset = None
        self.rng = np.random.default_rng(seed)

    def set_dataset(self, X):
        self.dataset = X

    def __call__(self, x):
        lam = self.rng.beta(self.alpha, self.alpha)
        if self.dataset is not None:
            x2 = self.dataset[self.rng.integers(0, len(self.dataset))]
        else:
            x2 = np.zeros_like(x)
        return lam * x + (1 - lam) * x2


# ─────────────────────────────────────────────────────────────────────────────
# NEW: EcologicalAug
# ─────────────────────────────────────────────────────────────────────────────

class EcologicalAug:
    """
    Ecologically-constrained community perturbation.

    Simulates realistic community perturbations by propagating taxon dropout
    through a Spearman co-occurrence network:
      - Positive edges (rho > threshold): co-occurring taxa (cross-feeders)
        → dropping seed taxon reduces co-occurring neighbors
      - Negative edges (rho < -threshold): competing taxa
        → dropping seed taxon releases competing neighbors

    Parameters
    ----------
    pos_neighbors : dict {int: [(neighbor_idx, rho_value), ...]}
        Positive co-occurrence neighbors per feature index.
    neg_neighbors : dict {int: [(neighbor_idx, rho_value), ...]}
        Negative co-occurrence (competitive) neighbors per feature index.
    k_seeds_range : tuple (int, int)
        Range for number of seed taxa to perturb per augmentation.
    alpha_range : tuple (float, float)
        Range for perturbation strength multiplier.
    seed : int or None
    """
    def __init__(self, pos_neighbors, neg_neighbors,
                 k_seeds_range=(1, 5), alpha_range=(0.1, 0.4), seed=None):
        self.name = "EcologicalAug"
        self.pos_neighbors = pos_neighbors
        self.neg_neighbors = neg_neighbors
        self.k_seeds_range = k_seeds_range
        self.alpha_range = alpha_range
        self.rng = np.random.default_rng(seed)
        self.n_features = len(pos_neighbors)

    def __call__(self, x):
        x_aug = x.copy()
        alpha = self.rng.uniform(*self.alpha_range)

        # Select k seed taxa to perturb
        k = self.rng.integers(self.k_seeds_range[0], self.k_seeds_range[1] + 1)
        seeds = self.rng.choice(self.n_features, size=k, replace=False)

        for seed_idx in seeds:
            # Zero out the seed taxon (simulate non-detection)
            x_seed_val = x_aug[seed_idx]
            x_aug[seed_idx] = 0.0

            # Propagate to positive neighbors (co-occurring taxa reduced)
            for nbr_idx, rho_val in self.pos_neighbors[seed_idx]:
                reduction = alpha * abs(rho_val) * abs(x_aug[nbr_idx])
                x_aug[nbr_idx] = max(x_aug[nbr_idx] - reduction,
                                     x_aug[nbr_idx] - abs(x_aug[nbr_idx]))

            # Propagate to negative neighbors (competing taxa released)
            for nbr_idx, rho_val in self.neg_neighbors[seed_idx]:
                increase = alpha * abs(rho_val) * abs(x_seed_val)
                x_aug[nbr_idx] = x_aug[nbr_idx] + increase

        # Re-center to preserve CLR zero-sum constraint
        x_aug = x_aug - x_aug.mean()
        return x_aug

    @classmethod
    def from_network_file(cls, network_path, **kwargs):
        """Load from saved co-occurrence network pickle."""
        with open(network_path, "rb") as f:
            net = pickle.load(f)
        return cls(
            pos_neighbors=net["pos_neighbors"],
            neg_neighbors=net["neg_neighbors"],
            **kwargs
        )


# ─────────────────────────────────────────────────────────────────────────────
# NEW: CohortStyleAug
# ─────────────────────────────────────────────────────────────────────────────

class CohortStyleAug:
    """
    Inter-cohort technical variation simulation.

    Applies a partial cohort mean-shift transfer to simulate the systematic
    batch effects between cohorts (DNA extraction, library prep, sequencing
    depth, geographic/dietary confounders).

    For sample x from cohort c, randomly selects a target cohort c\'
    and applies: x_aug = x + beta * (mu_{c\'} - mu_c) + epsilon
    where beta ~ Uniform(0, beta_max) and epsilon ~ N(0, noise_std^2).

    Parameters
    ----------
    cohort_means : dict {cohort_id: np.ndarray of shape (n_features,)}
        Per-cohort mean CLR profiles.
    sample_cohorts : dict {sample_idx: cohort_id}
        Mapping from sample index to cohort ID.
    beta_max : float
        Maximum style transfer strength (0 = no transfer, 1 = full transfer).
    noise_std : float
        Additional Gaussian noise after style transfer.
    seed : int or None
    """
    def __init__(self, cohort_means, sample_cohorts,
                 beta_max=0.5, noise_std=0.05, seed=None):
        self.name = "CohortStyleAug"
        self.cohort_means = cohort_means          # {cohort_id: array}
        self.sample_cohorts = sample_cohorts      # {sample_idx: cohort_id}
        self.cohort_ids = list(cohort_means.keys())
        self.beta_max = beta_max
        self.noise_std = noise_std
        self.rng = np.random.default_rng(seed)
        # Current sample index — must be set before each call
        self._current_cohort = None

    def set_sample_cohort(self, cohort_id):
        """Set the cohort of the current sample before calling __call__."""
        self._current_cohort = cohort_id

    def __call__(self, x):
        # Select a random target cohort different from the current one
        other_cohorts = [c for c in self.cohort_ids if c != self._current_cohort]
        if not other_cohorts:
            return x.copy()  # only one cohort — no transfer possible

        target_cohort = self.rng.choice(other_cohorts)
        mu_current = self.cohort_means[self._current_cohort]
        mu_target  = self.cohort_means[target_cohort]

        # Partial style transfer
        beta = self.rng.uniform(0, self.beta_max)
        delta = mu_target - mu_current
        noise = self.rng.normal(0, self.noise_std, size=x.shape)

        x_aug = x + beta * delta + noise
        # Re-center to preserve CLR constraint
        x_aug = x_aug - x_aug.mean()
        return x_aug


# ─────────────────────────────────────────────────────────────────────────────
# Registry builder
# ─────────────────────────────────────────────────────────────────────────────

def build_registry(clade_groups, X_train=None,
                   network_path=None, cohort_means=None, sample_cohorts=None):
    """Build augmentation registry with dataset-dependent parameters."""
    registry = {
        "PhyloAug":     PhyloAug(clade_groups=clade_groups, p_clade=0.20, p_taxon=0.10),
        "CompAug":      CompAug(noise_std=0.15),
        "TaxDropAug":   TaxDropAug(drop_fraction=0.20, low_abundance_quantile=0.40),
        "FeatureMask":  FeatureMask(mask_fraction=0.30),
        "GaussianNoise":GaussianNoise(noise_std=0.15),
        "MixupAug":     MixupAug(alpha=0.2),
    }
    if X_train is not None:
        registry["FeatureMask"].set_marginals(X_train)
        registry["MixupAug"].set_dataset(X_train)

    if network_path is not None and os.path.exists(network_path):
        registry["EcologicalAug"] = EcologicalAug.from_network_file(
            network_path, k_seeds_range=(1, 5), alpha_range=(0.1, 0.4)
        )

    if cohort_means is not None and sample_cohorts is not None:
        registry["CohortStyleAug"] = CohortStyleAug(
            cohort_means=cohort_means,
            sample_cohorts=sample_cohorts,
            beta_max=0.5,
            noise_std=0.05,
        )

    return registry
