"""
MicroCLR Augmentation Library — v2 (corrected)
================================================
Fixes applied:
  1. PhyloAug uses real genus-level taxonomy (not contiguous index blocks)
  2. CompAug and GaussianNoise use same noise_std for fair comparison
     (CompAug adds re-centering; GaussianNoise does not)
  3. All augmentations validated on real MSP data

Microbiome-specific:
  PhyloAug   — genus-clade-aware taxon dropout (real taxonomy)
  CompAug    — CLR-space Gaussian + re-centering (compositional constraint)
  TaxDropAug — low-abundance taxon dropout (detection threshold simulation)

Generic baselines:
  FeatureMask  — SCARF-style feature masking from marginal distribution
  GaussianNoise — additive Gaussian noise (no re-centering)
  MixupAug     — convex combination of two samples
"""

import numpy as np
import json
import os

# Load clade groups (set path before use)
_CLADE_GROUPS = None

def load_clade_groups(path):
    global _CLADE_GROUPS
    with open(path) as f:
        _CLADE_GROUPS = json.load(f)
    return _CLADE_GROUPS


class PhyloAug:
    """
    Genus-clade-aware taxon dropout.
    Drops entire genera with probability p_clade, individual MSPs within
    surviving genera with probability p_taxon.
    Requires clade_groups dict {genus: [feature_indices]}.
    """
    def __init__(self, clade_groups, p_clade=0.20, p_taxon=0.10, seed=None):
        self.name = "PhyloAug"
        self.clade_groups = clade_groups  # dict: genus -> list of feature indices
        self.clade_list = list(clade_groups.values())
        self.p_clade = p_clade
        self.p_taxon = p_taxon
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        x_aug = x.copy()
        for idxs in self.clade_list:
            idxs = np.array(idxs)
            if self.rng.random() < self.p_clade:
                x_aug[idxs] = 0.0
            else:
                mask = self.rng.random(len(idxs)) < self.p_taxon
                x_aug[idxs[mask]] = 0.0
        nz = x_aug != 0
        if nz.sum() > 0:
            x_aug[nz] -= x_aug[nz].mean()
        return x_aug


class CompAug:
    """
    Compositional augmentation: CLR-space Gaussian noise + re-centering.
    Re-centering maintains the CLR sum-to-zero constraint, making this
    equivalent to a log-normal perturbation of relative abundances.
    Distinct from GaussianNoise (which does NOT re-center).
    """
    def __init__(self, noise_std=0.15, seed=None):
        self.name = "CompAug"
        self.noise_std = noise_std
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        noise = self.rng.normal(0, self.noise_std, size=x.shape)
        x_aug = x + noise
        x_aug = x_aug - x_aug.mean()  # re-center: CLR constraint
        return x_aug


class TaxDropAug:
    """
    Low-abundance taxon dropout.
    Zeros a random fraction of the lowest-abundance taxa (by CLR value),
    simulating detection threshold variation across protocols.
    """
    def __init__(self, drop_fraction=0.20, low_abundance_quantile=0.40, seed=None):
        self.name = "TaxDropAug"
        self.drop_fraction = drop_fraction
        self.low_abundance_quantile = low_abundance_quantile
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        x_aug = x.copy()
        threshold = np.quantile(x, self.low_abundance_quantile)
        low_idx = np.where(x <= threshold)[0]
        n_drop = max(1, int(len(low_idx) * self.drop_fraction))
        drop_idx = self.rng.choice(low_idx, size=n_drop, replace=False)
        x_aug[drop_idx] = 0.0
        nz = x_aug != 0
        if nz.sum() > 0:
            x_aug[nz] -= x_aug[nz].mean()
        return x_aug


class FeatureMask:
    """
    SCARF-style feature masking: replaces masked features with values
    drawn from the marginal distribution of that feature.
    """
    def __init__(self, mask_fraction=0.30, seed=None):
        self.name = "FeatureMask"
        self.mask_fraction = mask_fraction
        self.feature_marginals = None
        self.rng = np.random.default_rng(seed)

    def set_marginals(self, X):
        self.feature_marginals = X  # (n_samples, n_features)

    def __call__(self, x):
        x_aug = x.copy()
        n = len(x)
        n_mask = max(1, int(n * self.mask_fraction))
        mask_idx = self.rng.choice(n, size=n_mask, replace=False)
        if self.feature_marginals is not None:
            for idx in mask_idx:
                x_aug[idx] = self.rng.choice(self.feature_marginals[:, idx])
        else:
            x_aug[mask_idx] = 0.0
        return x_aug


class GaussianNoise:
    """
    Additive Gaussian noise in CLR space. Does NOT re-center.
    Generic baseline — same noise_std as CompAug for fair comparison.
    """
    def __init__(self, noise_std=0.15, seed=None):
        self.name = "GaussianNoise"
        self.noise_std = noise_std
        self.rng = np.random.default_rng(seed)

    def __call__(self, x):
        return x + self.rng.normal(0, self.noise_std, size=x.shape)


class MixupAug:
    """
    Mixup: convex combination of anchor with a random dataset sample.
    Label-unaware (uses random sample regardless of disease label).
    """
    def __init__(self, alpha=0.2, seed=None):
        self.name = "MixupAug"
        self.alpha = alpha
        self.dataset = None
        self.rng = np.random.default_rng(seed)

    def set_dataset(self, X):
        self.dataset = X

    def __call__(self, x):
        lam = self.rng.beta(self.alpha, self.alpha)
        if self.dataset is not None:
            x2 = self.dataset[self.rng.integers(0, len(self.dataset))]
        else:
            x2 = np.zeros_like(x)
        return lam * x + (1 - lam) * x2


def build_registry(clade_groups, X_train=None):
    """Build augmentation registry with dataset-dependent parameters."""
    registry = {
        "PhyloAug":     PhyloAug(clade_groups=clade_groups, p_clade=0.20, p_taxon=0.10),
        "CompAug":      CompAug(noise_std=0.15),
        "TaxDropAug":   TaxDropAug(drop_fraction=0.20, low_abundance_quantile=0.40),
        "FeatureMask":  FeatureMask(mask_fraction=0.30),
        "GaussianNoise":GaussianNoise(noise_std=0.15),
        "MixupAug":     MixupAug(alpha=0.2),
    }
    if X_train is not None:
        registry["FeatureMask"].set_marginals(X_train)
        registry["MixupAug"].set_dataset(X_train)
    return registry
