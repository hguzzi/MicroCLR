# Repository Update Instructions — MicroCLR v1.1.0 (BIOADV-2026-484, second revision)

This folder contains everything needed to bring the public repository
(https://github.com/hguzzi/MicroCLR) and its Zenodo archive up to date with the
revised manuscript. **The response letter quotes the push date, commit hash, and
Zenodo DOI in red placeholders — push first, then fill them in before submission.**

## What is in this bundle

```
MicroCLR/                     <- complete updated repository tree (overlay on the existing repo)
  README.md                   <- updated (v1.1.0 history, new structure, IBD exploratory note)
  requirements.txt
  CITATION.cff / codemeta.json<- version 1.1.0, corrected repo URL + journal
  augmentations/  data/  models/   <- unchanged from v1.0.0
  scripts/                    <- original scripts + 6 new analysis/figure scripts
  evaluation/                 <- original CSVs + CMD results + sensitivity JSONs (+ cmd/ A2-A6)
  figures/                    <- manuscript-final figures (superseded PNGs removed)
  manuscripts/                <- revised manuscript v6 + supplementary v6 (PDFs)
PUSH_INSTRUCTIONS.md          <- this file (do NOT commit to the repo)
```

## Step 1 — Push to GitHub

```bash
# 1. Clone the current public repository (or use your existing local clone)
git clone https://github.com/hguzzi/MicroCLR.git
cd MicroCLR

# 2. Make sure you are on the main branch and up to date
git checkout main
git pull origin main

# 3. Copy the contents of the bundle's MicroCLR/ folder over this clone
#    (overwrite existing files, add new ones)
cp -r /path/to/repository_bundle/MicroCLR/* .

# 4. Review what changed, then stage everything
git add -A
git status          # verify: modified README.md, CITATION.cff, codemeta.json;
                    #         new scripts/, evaluation/ files; updated figures/, manuscripts/

# 5. Commit and push
git commit -m "v1.1.0: second-revision materials for BIOADV-2026-484

- Add CMD analysis scripts and results (participant-grouped CV, inductive
  evaluation, nested tuning, Mixup alternatives, RF-on-embeddings)
- Add re-centering and masking-rate sensitivity results
- Regenerate all main-text figures with harmonized colors and defined labels
- Report IGC2/HGMA IBD results separately as exploratory (manuscript Section 3.13)
- Update README, requirements.txt, CITATION.cff, codemeta.json"
git push origin main

# 6. Tag the release
git tag -a v1.1.0 -m "Version 1.1.0 - second revision materials"
git push origin v1.1.0

# 7. Record the push date and commit hash (needed for the response letter)
git log -1 --format="%H %ad" --date=iso
```

**Verify in the browser** after pushing: the README renders, the new scripts and
evaluation files are visible, and the figures match the revised manuscript.

## Step 2 — Zenodo new version

1. Go to https://zenodo.org/ and open your existing record
   (https://zenodo.org/records/20751445).
2. On the record page, click **"New version"** (right-hand panel).
3. Zenodo creates a draft; upload the updated files:
   - Easiest: upload a zip of the updated repository
     (`MicroCLR_repository_update_v1.1.0.zip` in this bundle, minus this
     instructions file).
   - Or upload the individual updated files, mirroring the repository layout.
4. On the upload form, set:
   - **Version:** 1.1.0
   - **Publication date:** the day you publish (e.g., 2026-10-18)
   - **Description:** "Second-revision materials for BIOADV-2026-484: CMD analysis
     scripts and results, sensitivity analyses, regenerated figures with harmonized
     color scheme, exploratory IGC2/HGMA IBD results separated from primary analyses."
5. **Publish.** Zenodo mints a new version DOI (the concept DOI
   10.5281/zenodo.20751445 stays stable and automatically resolves to the latest
   version).

## Step 3 — Fill in the response letter

Open `response_letter_round2_BIOADV-2026-484.tex` and replace the three red
placeholders:

| Placeholder | Value |
|---|---|
| `[DATE --- fill in after pushing]` | push date, e.g., 18 October 2026 |
| `[COMMIT HASH]` | output of `git log -1 --format=%H` |
| `[ZENODO VERSION / DOI]` | the new version DOI from Step 2 |

Then recompile the letter (tectonic or Overleaf) and check that no red text remains.

## Pre-submission checklist

- [ ] `git push` succeeded and the new commit is visible on GitHub
- [ ] Tag `v1.1.0` pushed
- [ ] README renders correctly on GitHub (tables, code blocks)
- [ ] Zenodo new version published; new version DOI noted
- [ ] Zenodo concept DOI (…20751445) resolves to the new version
- [ ] Response letter placeholders replaced; letter recompiled with no red text
- [ ] Manuscript PDF still cites the correct repository and Zenodo URLs
      (https://github.com/hguzzi/MicroCLR, https://zenodo.org/records/20751445)
- [ ] Spot-check: the quick-start code in the README runs without the
      `encoder_state_dict` error reported by Reviewer 3
- [ ] All files described in the response letter ("The update contains:") are
      actually visible in the public repository
